/* Generated from Nous_Source.js; sha256: 246808f02d46e0ba23ad4040d58d9c84b222c093a9a49904f659615b893a7887. Do not edit. */
(() => {
  const id='nous-bookmarklet',previous=document.getElementById(id);
  try{
/* NOUS_SOURCE_START */
/* Nous 1.6 — Personalize. Follow the thread. Standalone, local resource inspector. */
(() => {
  'use strict';
  const ID = 'nous-bookmarklet';
  const existing = document.getElementById(ID);
  if (existing) { existing.dispatchEvent(new Event('nous:close')); return; }
  const legacy = document.getElementById('resource-radar-bookmarklet');
  if (legacy) legacy.remove();
  const previousFocus = document.activeElement;
  const host = document.createElement('div');
  host.id = ID;
  host.style.cssText = 'all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;pointer-events:none!important;display:block!important;isolation:isolate!important;';
  const root = host.attachShadow({mode:'open'});
  const icons = {
    settings:'<path d="M12 3v3m0 12v3M3 12h3m12 0h3M5.6 5.6l2.1 2.1m8.6 8.6 2.1 2.1M5.6 18.4l2.1-2.1m8.6-8.6 2.1-2.1"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    search:'<circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.5 4.5"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 6.1a8 8 0 0 1 13.2 3M17.9 17.9a8 8 0 0 1-13.2-3"/>',
    copy:'<rect x="8" y="8" width="12" height="12" rx="3"/><path d="M15 4H7a3 3 0 0 0-3 3v8"/>',
    download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    minimize:'<path d="M6 12h12"/>',
    expand:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
    restore:'<path d="M3 8h5V3m8 0v5h5M8 21v-5H3m18 0h-5v5"/>',
    external:'<path d="M14 3h7v7m0-7L10 14M10 4H6a3 3 0 0 0-3 3v11a3 3 0 0 0 3 3h11a3 3 0 0 0 3-3v-4"/>',
    arrow:'<path d="m9 5 7 7-7 7"/>',
    back:'<path d="m15 5-7 7 7 7"/>',
    link:'<path d="m10 14 4-4m-6 6-2 2a4.2 4.2 0 0 1-6-6l4-4a4.2 4.2 0 0 1 6 0m2 0 2-2a4.2 4.2 0 0 1 6 6l-4 4a4.2 4.2 0 0 1-6 0" transform="translate(2 0)"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 16-5-5-8 10M3 16l4-4 4 4"/>',
    video:'<rect x="3" y="4" width="18" height="16" rx="5"/><path d="m10 8 6 4-6 4Z"/>',
    audio:'<path d="M9 17V5l11-2v12M9 8l11-2"/><ellipse cx="5.5" cy="18" rx="3.5" ry="3"/><ellipse cx="16.5" cy="16" rx="3.5" ry="3"/>',
    code:'<path d="m7 6-5 6 5 6m10-12 5 6-5 6m-4-15-3 18"/>',
    style:'<path d="M12 3 3 8l9 5 9-5-9-5ZM3 12l9 5 9-5M3 16l9 5 9-5"/>',
    frame:'<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M3 9h18M8 9v12"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
    network:'<circle cx="12" cy="4" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M12 6v5m-7 6v-6h14v6"/>',
    grid:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    thread:'<path d="M4 18V7a3 3 0 0 1 5.3-1.9l6.4 13.8A3 3 0 0 0 21 17V6"/>',
    target:'<circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="1"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4"/>',
    eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>'
  };
  const icon = (name, cls='') => '<svg class="icon '+cls+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(icons[name]||icons.link)+'</svg>';
  const mark = '<svg viewBox="0 0 36 36" fill="none" aria-hidden="true"><path d="M9 26V11a3 3 0 0 1 5.5-1.7l7 17.4A3 3 0 0 0 27 25V10" stroke="currentColor" stroke-width="3.4" stroke-linecap="round"/><circle cx="27" cy="6" r="2" fill="currentColor"/></svg>';
  root.innerHTML = `<style>
    :host{all:initial;color-scheme:light}
    *,*::before,*::after{box-sizing:border-box}
    button,input,a{-webkit-tap-highlight-color:transparent}
    button,input{font:inherit}
    button{border:0;cursor:pointer;touch-action:manipulation}
    button:disabled{opacity:.4;cursor:default}
    button:focus-visible,a:focus-visible,[tabindex]:focus-visible{outline:2px solid #25846c;outline-offset:-3px}
    button:active:not(:disabled){background:#d5ebe3}
    button svg{pointer-events:none}
    [hidden]{display:none!important}
    .icon{display:block;width:18px;height:18px;flex:none}
    .dock{--mint:#85e2ce;--text:#253f37;--muted:#63786f;--line:#cddbd5;position:absolute;inset:0;pointer-events:none;font:13px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;letter-spacing:0;color:var(--text);text-align:left;-webkit-font-smoothing:antialiased}
    .sheet,.preview{position:absolute;pointer-events:auto;left:50%;transform:translateX(-50%);width:min(100%,900px);display:flex;flex-direction:column;min-height:0;overflow:hidden;background:#f0f5f2;border:1px solid #b8cdc3;border-bottom:0;border-radius:12px 12px 0 0;box-shadow:none;color:var(--text)}
    .sheet{bottom:0}
    .preview{bottom:0;z-index:2;background:#edf4ef;border-top-color:#9fbfaf}
    .grab{height:14px;display:flex;align-items:center;justify-content:center;flex:none;touch-action:none;cursor:ns-resize;background:#e5efea}
    .grab::before{content:'';height:3px;width:38px;border-radius:3px;background:#91ada0}
    .bar{display:flex;align-items:center;gap:8px;min-height:39px;padding:0 5px 4px 10px;flex:none;background:#e5efea;border-bottom:1px solid var(--line)}
    .brandmark{display:grid;place-items:center;width:27px;height:27px;flex:none;background:var(--mint);border-radius:8px;color:#16352f}
    .brandmark svg{width:23px;height:23px}
    .brandblock{display:flex;align-items:baseline;gap:7px;flex:1;min-width:0}
    .wordmark{font-size:20px;font-weight:750;line-height:1;letter-spacing:-.9px}
    .brandtag{font-size:10px;color:#637c70;white-space:nowrap}
    .windowtools{display:flex;gap:1px;flex:none}
    .iconbutton{display:grid;place-items:center;width:38px;height:34px;flex:none;border-radius:4px;background:transparent;color:#587165}
    .iconbutton:hover{background:#d8e7df}
    .iconbutton .icon{width:17px;height:17px}
    #close:hover,#previewclose:hover{background:#f2dfdc;color:#8e4f49}
    .pagecontext{display:flex;align-items:center;gap:6px;min-height:27px;padding:4px 11px;background:#f6f9f7;border-bottom:1px solid #dbe4df;color:#637b6f;font-size:10px;flex:none;min-width:0}
    .pagecontext .dot{width:4px;height:4px;background:#31896f;border-radius:50%;flex:none}
    #site{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}
    .totalpill{font-size:10px;color:#436e5b;white-space:nowrap;font-variant-numeric:tabular-nums}
    .tools{display:flex;align-items:stretch;flex:none;min-height:36px;background:#edf3ef;border-bottom:1px solid var(--line)}
    .tool{display:flex;align-items:center;justify-content:center;gap:6px;min-height:36px;padding:0 12px;border:0;border-right:1px solid #d5e1da;background:transparent;border-radius:0;color:#3d6351;font-size:11px;font-weight:550;white-space:nowrap}
    .tool .icon{width:14px;height:14px}
    .tool:hover{background:#dcece2}
    .tabs{display:flex;gap:0;overflow:auto;flex:none;scrollbar-width:none;overscroll-behavior:contain;background:#e7efea;border-bottom:1px solid #bfcec5;min-height:38px;padding:0}
    .tabs::-webkit-scrollbar{display:none}
    .tab{display:flex;align-items:center;justify-content:center;gap:5px;min-height:37px;padding:0 11px;white-space:nowrap;border-radius:0;border:0;border-right:1px solid #d6e0d9;border-bottom:2px solid transparent;color:#60786b;background:transparent;font-size:11px;font-weight:500;flex:none}
    .tab.active{background:#f8fcfa;color:#226c55;border-bottom-color:#329a7a;font-weight:650}
    .tab .num{font-size:9px;font-weight:500;color:#788c80;font-variant-numeric:tabular-nums}
    .tab.active .num{color:#3b8067}
    .tab .icon{height:12px;width:12px}
    .searchline{display:flex;align-items:center;gap:0;padding:6px 9px;flex:none;background:#f7faf8;border-bottom:1px solid #d9e3dc}
    .searchbox{position:relative;display:flex;align-items:center;gap:8px;background:#fff;border:1px solid #bfcec5;border-radius:5px;padding:0 9px;min-width:0;flex:1;height:34px;color:#7b9185}
    .searchbox:focus-within{border-color:#479d7c}
    .searchbox .icon{width:15px;height:15px}
    #find{color:#2c4b3c;background:transparent;border:0;outline:none;appearance:none;-webkit-appearance:none;font-size:16px;min-width:0;width:100%;height:100%;padding:0;letter-spacing:-.2px}
    #find::placeholder{color:#7f9487}
    .listhead{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:24px;padding:4px 10px;flex:none;background:#edf3ef;border-bottom:1px solid #dce5df;color:#658073;font-size:9px;font-weight:550;letter-spacing:.25px}
    #hint{font-size:9px;letter-spacing:0;font-weight:400;color:#82968a}
    .items{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;padding:0;background:#fff}
    .item{display:flex;align-items:center;gap:0;min-width:0;background:#fff;border:0;border-bottom:1px solid #e0e8e2;border-radius:0;margin:0}
    .item:nth-child(even){background:#f7faf8}
    .item.selected{background:#e1f2e9;border-left:2px solid #42a17e}
    .item:hover{background:#edf6f0}
    .resource{display:flex;align-items:center;gap:8px;flex:1;min-width:0;text-align:left;background:transparent;color:inherit;padding:8px 0 8px 10px;border-radius:0}
    .avatar{display:grid;place-items:center;flex:none;width:21px;height:26px;border-radius:0;color:var(--row-color,#436e99);background:transparent;align-self:flex-start;margin-top:4px}
    .avatar .icon{width:16px;height:16px}
    .itemmain{min-width:0;flex:1}
    .eyebrow{display:flex;align-items:center;gap:5px;color:#7c9083;font-size:9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:1px}
    .eyebrow .type{color:var(--row-color,#436e99);font-weight:550}
    .eyebrow .sep{width:2px;height:2px;border-radius:50%;background:#97aa9b;flex:none}
    .label{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;overflow:hidden;font-size:12px;font-weight:600;color:#2a4a3b;line-height:1.3}
    .val{font-size:10px;color:#587c69;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px;line-height:1.35}
    .copyitem{display:grid;place-items:center;width:42px;min-height:53px;align-self:stretch;flex:none;background:transparent;color:#7b9385;border-radius:0}
    .copyitem .icon{width:14px;height:14px}
    .copyitem:hover{color:#257357;background:#dceee1}
    .empty{padding:24px 16px;text-align:center;color:#708777}
    .empty .avatar{margin:0 auto 9px;width:30px;height:30px}
    .empty strong{display:block;color:#365442;font-size:13px;margin-bottom:5px}
    .empty p{margin:0;line-height:1.6;font-size:11px}
    .more{display:block;min-height:36px;padding:8px 16px;margin:9px auto;background:#edf5ef;border:1px solid #c7dace;color:#3e7256;border-radius:4px;font-size:11px}
    .foot{flex:none;border-top:1px solid #c7d6cc;background:#e7efea;padding:5px 10px calc(5px + env(safe-area-inset-bottom,0px));display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:25px}
    .sheet.split .foot{padding-bottom:5px}
    .state{display:flex;align-items:center;gap:6px;flex:1;min-width:0}
    .miniicon{display:grid;place-items:center;color:#49806a;flex:none}
    .miniicon .icon{width:13px;height:13px}
    .statecaption{font-size:9px;color:#5c7b68;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .footbrand{font-size:9px;color:#748e7d;white-space:nowrap}
    .toast{position:absolute;bottom:calc(35px + env(safe-area-inset-bottom,0px));left:50%;transform:translateX(-50%);max-width:calc(100% - 24px);padding:8px 12px;border:1px solid #a1c4af;border-radius:5px;background:#e3f4e9;color:#2c674b;font-size:11px;font-weight:550;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none;z-index:4}
    .sheet.minimized{width:min(100%,900px);border-radius:10px 10px 0 0;bottom:0!important}
    .sheet.minimized .bar{height:49px;min-height:49px;padding:6px 5px 6px 10px;border-bottom:0}
    .sheet.minimized>.grab,.sheet.minimized>.pagecontext,.sheet.minimized>.tools,.sheet.minimized>.tabs,.sheet.minimized>.searchline,.sheet.minimized>.listhead,.sheet.minimized>.items,.sheet.minimized>.foot{display:none}
    .peekbar{display:flex;align-items:center;gap:7px;min-height:38px;padding:0 5px 4px 10px;flex:none;background:#e5efea;border-bottom:1px solid #cfddd3}
    .peekmark{display:grid;place-items:center;width:22px;height:26px;color:#3d8769;flex:none}
    .peekmark .icon{width:17px;height:17px}
    .peektitle{flex:1;min-width:0}
    .peektitle strong{display:block;font-size:12px;font-weight:650;color:#2d5941}
    .peektitle small{display:block;font-size:9px;color:#708a77;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .peekbar .iconbutton{width:34px;height:32px}
    .actionpill{display:flex;align-items:center;justify-content:center;gap:5px;min-height:31px;padding:0 9px;border:1px solid #b8cfc0;border-radius:4px;background:#f7fbf8;color:#386c4c;font-size:10px;font-weight:600}
    .actionpill .icon{width:12px;height:12px}
    .previewaddress{display:flex;align-items:center;gap:6px;margin:0;padding:5px 10px;background:#f5f9f6;border-bottom:1px solid #d1dfd5;min-height:27px;flex:none}
    .previewaddress>.icon{width:12px;height:12px;color:#66917a}
    .previewaddress span{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:10px;color:#658572}
    .previewcanvas{position:relative;flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;background:#fff}
    .previewcanvas iframe{display:block;width:100%;height:100%;border:0;background:white}
    .imagestage{height:100%;width:100%;display:flex;align-items:center;justify-content:center;overflow:auto;background:#f0f5f2;padding:8px}
    .imagestage img{display:block;max-width:100%;max-height:100%;width:auto;height:auto;object-fit:contain;border-radius:0}
    .previewcanvas video{display:block;width:100%;height:100%;background:#111}
    .audiostage{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:12px;background:#edf4ef}
    .audiostage .avatar{width:32px;height:32px;align-self:center;margin:0;color:#3c8764}
    .audiostage audio{max-width:100%;width:320px}
    .plainpreview{padding:12px;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;color:#365742;font:12px/1.6 ui-monospace,SFMono-Regular,monospace}
    .previewfoot{display:flex;align-items:center;gap:6px;min-height:24px;padding:5px 10px calc(5px + env(safe-area-inset-bottom,0px));background:#e7efea;border-top:1px solid #c7d6cc;font-size:9px;color:#668370;flex:none}
    .previewfoot .icon{width:12px;height:12px;color:#49866b}
    #previewfoot{min-width:0}
    .copydialog{pointer-events:auto;position:absolute;inset:0;z-index:8;display:grid;place-items:center;padding:18px;background:#294c3c55}
    .copycard{width:min(100%,490px);padding:16px;border-radius:10px;background:#f1f7f3;border:1px solid #b4ccbc}
    .copycard header{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px}
    .copycard h2{margin:0;font-size:16px}
    .copycard p{color:#6b8772;font-size:11px;margin:0 0 12px}
    .copycard textarea{width:100%;height:140px;resize:vertical;border-radius:4px;padding:10px;border:1px solid #b4cbba;background:#fff;color:#244d32;font:16px/1.5 ui-monospace,monospace}
    .copycard .actionpill{margin-top:10px;width:100%;height:38px;background:#d9f1e3;color:#2a6240}
    .micro .pagecontext,.micro .foot,.micro .listhead{display:none}
    @media(max-width:359px){.brandtag{display:none}.tool{padding:0 10px}.tab{padding:0 10px}.footbrand{display:none}}
    @media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;transition:none!important}}

    .dock{--accent:#329a7a;--accent-ink:#226c55;--accent-soft:#e1f2e9;--resource-size:12px}
    .dock[data-accent="blue"]{--mint:#b2d0ff;--accent:#4a76bc;--accent-ink:#2f5b99;--accent-soft:#e5efff}
    .dock[data-accent="violet"]{--mint:#cfc1ef;--accent:#8660b5;--accent-ink:#6c478f;--accent-soft:#f0eaf8}
    .dock[data-accent="amber"]{--mint:#f2d59e;--accent:#aa792d;--accent-ink:#815a20;--accent-soft:#fbf0da}
    .grab{height:32px;min-height:32px;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
    .grab::before{background:#91ada0;pointer-events:none}
    .grab.held::before{width:52px;background:var(--accent)}
    .bar,.peekbar{touch-action:none;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;cursor:ns-resize}
    .dragshield{position:absolute;inset:0;z-index:6;pointer-events:auto;touch-action:none;background:transparent;cursor:ns-resize}
    .tabstrip{display:flex;flex:none;min-width:0;background:#e7efea;border-bottom:1px solid #bfcec5}
    .tabstrip>.tabs{flex:1;min-width:0;border-bottom:0}
    .settingstab{border-left:1px solid #bfcec5;border-right:0;gap:5px}
    .settingstab .icon{width:14px;height:14px}
    .tab.active{color:var(--accent-ink);border-bottom-color:var(--accent)}
    .tab.active .num{color:var(--accent-ink)}
    .item.selected{background:var(--accent-soft);border-left-color:var(--accent)}
    .label{font-size:var(--resource-size)}
    .val{font-size:calc(var(--resource-size) - 2px)}
    .eyebrow{font-size:calc(var(--resource-size) - 3px)}
    .dock.wrapurls .val{white-space:normal;overflow-wrap:anywhere;word-break:break-word}
    .dock[data-density="comfortable"] .resource{padding-top:13px;padding-bottom:13px}
    .dock[data-density="comfortable"] .copyitem{min-height:63px}
    .sheet.minimized>.tabstrip,.sheet.minimized>.settingspanel{display:none}
    .sourcespanel{display:flex;flex-direction:column;flex:1;min-height:0;overflow:hidden;background:#fff}
    .dock[data-theme="dark"] .sourcespanel{background:#202b24}
    .sheet.minimized>.sourcespanel{display:none}
    .sourcecode{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;margin:0;padding:8px 10px;white-space:pre-wrap;overflow-wrap:anywhere;tab-size:2;color:var(--text);font:11px/1.55 ui-monospace,SFMono-Regular,monospace;user-select:text;-webkit-user-select:text}
    .sourcecode .sourcetag{color:#a02c98}
    .sourcecode .sourceattr{color:#c53b3b}
    .dock[data-theme="dark"] .sourcecode .sourcetag{color:#e0a1dc}
    .dock[data-theme="dark"] .sourcecode .sourceattr{color:#f3a09a}
    .settingspanel{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;background:#fff}
    .settingsgroup{padding:9px 12px 7px;background:#edf3ef;border-bottom:1px solid #d3dfd6;color:#658073;font-size:10px;font-weight:650}
    .settingrow{display:flex;align-items:center;justify-content:space-between;gap:14px;min-height:45px;padding:8px 12px;border-bottom:1px solid #e0e8e2;font-size:12px;color:#365442}
    .settingrow select{max-width:52%;min-height:32px;padding:4px 8px;border:1px solid #bfcec5;border-radius:4px;background:#f7faf8;color:var(--text);font-family:inherit;font-size:16px}
    .settingrange{flex-wrap:wrap;gap:4px 10px}
    .settingrange output{font-size:11px;color:var(--accent-ink);font-variant-numeric:tabular-nums}
    .settingrange input{width:100%;height:27px;margin:0;accent-color:var(--accent)}
    .switchwrap{position:relative;display:inline-flex;align-items:center;flex:none;width:38px;height:24px}
    .switchwrap input{position:absolute;inset:0;z-index:1;width:100%;height:100%;margin:0;opacity:0;cursor:pointer}
    .switchtrack{display:block;width:36px;height:21px;border-radius:12px;background:#b9c8bf;pointer-events:none}
    .switchtrack::after{content:'';display:block;width:17px;height:17px;margin:2px;border-radius:50%;background:#fff}
    .switchwrap input:checked+.switchtrack{background:var(--accent)}
    .switchwrap input:checked+.switchtrack::after{transform:translateX(15px)}
    .switchwrap input:focus-visible+.switchtrack{outline:2px solid var(--accent-ink);outline-offset:2px}
    .settingsbottom{padding:12px}
    .settingsbottom .actionpill{min-height:36px;font-size:11px}
    .settingsbottom p{margin:9px 0 2px;font-size:10px;color:#708777;line-height:1.5}
    .dock[data-theme="dark"]{color-scheme:dark;--text:#dce9e3;--muted:#a0b3aa;--line:#3c4e44;--accent-ink:var(--mint);--accent-soft:#304539}
    .dock[data-theme="dark"] .sheet,.dock[data-theme="dark"] .preview{background:#242f29;border-color:#506356}
    .dock[data-theme="dark"] .grab,.dock[data-theme="dark"] .bar,.dock[data-theme="dark"] .peekbar{background:#2b3930;border-color:#425348}
    .dock[data-theme="dark"] .brandtag,.dock[data-theme="dark"] .iconbutton,.dock[data-theme="dark"] .pagecontext,.dock[data-theme="dark"] .peektitle small,.dock[data-theme="dark"] .previewaddress span{color:#a1b7a8}
    .dock[data-theme="dark"] .pagecontext,.dock[data-theme="dark"] .searchline,.dock[data-theme="dark"] .previewaddress{background:#26332b;border-color:#425348}
    .dock[data-theme="dark"] .tools,.dock[data-theme="dark"] .tabstrip,.dock[data-theme="dark"] .tabs,.dock[data-theme="dark"] .listhead,.dock[data-theme="dark"] .foot,.dock[data-theme="dark"] .previewfoot{background:#29372d;border-color:#425348}
    .dock[data-theme="dark"] .tool,.dock[data-theme="dark"] .tab{color:#a7bdad;border-right-color:#425348}
    .dock[data-theme="dark"] .settingstab{border-left-color:#425348}
    .dock[data-theme="dark"] .tab.active{background:#202b24;color:var(--accent-ink);border-bottom-color:var(--accent)}
    .dock[data-theme="dark"] .tab .num,.dock[data-theme="dark"] #hint{color:#8ba292}
    .dock[data-theme="dark"] .searchbox,.dock[data-theme="dark"] .copycard textarea{background:#19231d;border-color:#506356}
    .dock[data-theme="dark"] #find,.dock[data-theme="dark"] .label,.dock[data-theme="dark"] .peektitle strong,.dock[data-theme="dark"] .plainpreview,.dock[data-theme="dark"] .copycard textarea{color:#deece2}
    .dock[data-theme="dark"] #find::placeholder{color:#91a799}
    .dock[data-theme="dark"] .items,.dock[data-theme="dark"] .item,.dock[data-theme="dark"] .settingspanel{background:#202b24;border-color:#35483a}
    .dock[data-theme="dark"] .item:nth-child(even){background:#243128}
    .dock[data-theme="dark"] .item.selected{background:var(--accent-soft)}
    .dock[data-theme="dark"] .item:hover,.dock[data-theme="dark"] .iconbutton:hover,.dock[data-theme="dark"] .tool:hover{background:#344a3b}
    .dock[data-theme="dark"] .val,.dock[data-theme="dark"] .eyebrow,.dock[data-theme="dark"] .copyitem,.dock[data-theme="dark"] .statecaption,.dock[data-theme="dark"] .footbrand,.dock[data-theme="dark"] .previewfoot,.dock[data-theme="dark"] .empty,.dock[data-theme="dark"] .settingsbottom p{color:#9fb9a6}
    .dock[data-theme="dark"] .avatar,.dock[data-theme="dark"] .eyebrow .type,.dock[data-theme="dark"] .totalpill,.dock[data-theme="dark"] .miniicon,.dock[data-theme="dark"] .peekmark{color:var(--mint)}
    .dock[data-theme="dark"] .actionpill,.dock[data-theme="dark"] .more{background:#2c3d31;border-color:#506356;color:#b5d6be}
    .dock[data-theme="dark"] .settingsgroup{background:#29372d;border-color:#425348;color:#9fb9a6}
    .dock[data-theme="dark"] .settingrow{color:#dce9e3;border-color:#35483a}
    .dock[data-theme="dark"] .settingrow select{background:#2a3930;border-color:#506356}
    .dock[data-theme="dark"] .imagestage,.dock[data-theme="dark"] .audiostage,.dock[data-theme="dark"] .copycard{background:#26342b;border-color:#506356}
    .dock[data-theme="dark"] .copycard p{color:#a0b8a7}


    #inspectback{display:flex;align-items:center;gap:2px;min-height:28px;margin:-4px 0 -4px -5px;padding:0 5px;color:var(--accent-ink);background:transparent;font-size:11px;white-space:nowrap}
    #inspectback .icon{width:12px;height:12px}
    .sheet.micro.has-history:not(.minimized) .pagecontext{display:flex}
    #inspectpage{white-space:nowrap;min-height:34px;color:var(--accent-ink);background:var(--accent-soft)}
    @media(max-width:359px){.peekbar{gap:4px}.peekbar .iconbutton{width:29px}.peekbar .actionpill{padding:0 6px}}
    .revealitem{width:48px;color:var(--accent-ink);font-size:10px;font-weight:550}
    .dock.revealing .sheet,.dock.revealing:not(.revealing-frame) .preview{visibility:hidden;pointer-events:none}
    .dock.revealing-frame #viewer{display:flex!important;inset:0!important;height:auto!important;width:100%;transform:none;border:0;border-radius:0}
    .dock.revealing-frame .preview>:not(.previewcanvas),.dock.revealing-frame .previewcanvas>:not(.reveal-document){display:none!important}
    .dock.revealing-frame .reveal-document{display:block!important}
    .revealring{position:absolute;z-index:7;pointer-events:none;border:2px solid var(--accent);border-radius:4px;box-shadow:0 0 0 3px var(--accent-soft),0 0 0 9999px #10271e18}
    .revealhud{position:absolute;z-index:8;pointer-events:auto;bottom:calc(12px + env(safe-area-inset-bottom,0px));left:50%;transform:translateX(-50%);width:min(calc(100% - 20px),620px);padding:10px 12px;border:1px solid var(--line);border-radius:12px;background:#f5faf7;box-shadow:0 8px 32px #10271e26;color:var(--text)}
    .revealheading,.revealcontrols{display:flex;align-items:center;gap:8px}
    .revealheading strong{flex:1;font-size:12px;color:var(--accent-ink)}
    .revealhud .actionpill{min-height:40px;padding:0 12px}
    #revealagain{width:40px;height:40px;color:var(--accent-ink)}
    #revealurl{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px;color:var(--muted);margin:4px 0}
    #revealstatus{font-size:11px;line-height:1.5;overflow-wrap:anywhere;margin:6px 0 10px}
    #revealcount{font-size:11px;font-variant-numeric:tabular-nums;min-width:60px;text-align:center}
    #revealjump{margin-left:auto}
    .dock[data-theme="dark"] .revealhud{background:#242f29}
    @media(max-height:420px){.revealhud{padding:6px 10px}.revealhud .actionpill{min-height:36px}#revealagain{height:32px}#revealurl{display:none}#revealstatus{margin:3px 0 6px;font-size:10px}}
  </style>
  <div class="dock">
    <section class="sheet" role="region" aria-label="Nous resource inspector">
      <div class="grab" id="grab" role="separator" tabindex="0" aria-label="Resize inspector" aria-orientation="horizontal" aria-valuemin="0" aria-valuemax="100" title="Drag or use arrow keys to resize"></div>
      <header class="bar"><span class="brandmark">${mark}</span><div class="brandblock"><div class="wordmark">nous</div><div class="brandtag">mobile inspector</div></div><div class="windowtools"><button class="iconbutton" id="minimize" aria-label="Minimize Nous" title="Minimize">${icon('minimize')}</button><button class="iconbutton" id="maximize" aria-label="Expand inspector" title="Expand">${icon('expand')}</button><button class="iconbutton" id="close" aria-label="Close Nous" title="Close">${icon('close')}</button></div></header>
      <div class="pagecontext"><button type="button" id="inspectback" hidden aria-label="Previous inspected page">${icon('back')}Back</button><span class="dot"></span><span id="site"></span><span class="totalpill" id="total">0 found</span></div>
      <div class="tools" role="toolbar" aria-label="Inspector actions"><button class="tool" id="scan" aria-label="Rescan page">${icon('refresh')}Rescan</button><button class="tool" id="copy" aria-label="Copy filtered list">${icon('copy')}Copy list</button><button class="tool" id="save" aria-label="Export filtered list as JSON">${icon('download')}Export JSON</button></div>
      <div class="tabstrip"><nav class="tabs" id="tabs" aria-label="Resource categories"></nav><button class="tab settingstab" id="settingstab" aria-controls="settingspanel" aria-pressed="false">${icon('settings')}Settings</button><button class="tab settingstab" id="sourcestab" aria-controls="sourcespanel" aria-pressed="false">Sources</button></div>
      <div class="searchline"><label class="searchbox">${icon('search')}<input id="find" type="search" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" placeholder="Search resources…" aria-label="Search resources"></label></div>
      <div class="listhead"><span id="count" role="status" aria-live="polite">RESOURCES</span><span id="hint">Tap to peek</span></div>
      <div class="items" id="items" aria-label="Resources"></div>
      <section class="sourcespanel" id="sourcespanel" hidden aria-label="Current page HTML">
        <div class="listhead"><span>Current page · live HTML</span><button class="iconbutton" id="sourcecopy" aria-label="Copy page HTML" title="Copy page HTML">${icon('copy')}</button></div>
        <pre class="sourcecode" id="sourcecode" tabindex="0" aria-label="Read-only page HTML"></pre>
      </section>
      <section class="settingspanel" id="settingspanel" hidden aria-label="Nous settings">
        <div class="settingsgroup">Appearance</div>
        <label class="settingrow"><span>Theme</span><select id="setting-theme" aria-label="Theme"><option value="light">Light</option><option value="dark">Dark</option><option value="system">Device</option></select></label>
        <label class="settingrow"><span>Accent</span><select id="setting-accent" aria-label="Accent color"><option value="mint">Mint</option><option value="blue">Blue</option><option value="violet">Violet</option><option value="amber">Amber</option></select></label>
        <div class="settingrow settingrange"><label for="setting-textSize">Resource text</label><output id="textSize-value" for="setting-textSize">12 px</output><input id="setting-textSize" type="range" min="11" max="16" step="1" aria-label="Resource text size"></div>
        <label class="settingrow"><span>Row spacing</span><select id="setting-density" aria-label="Row spacing"><option value="compact">Compact</option><option value="comfortable">Comfortable</option></select></label>
        <label class="settingrow"><span>Wrap long URLs</span><span class="switchwrap"><input id="setting-wrapUrls" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <div class="settingsgroup">Panels</div>
        <div class="settingrow settingrange"><label for="setting-inspectorHeight">Inspector height</label><output id="inspectorHeight-value" for="setting-inspectorHeight">60%</output><input id="setting-inspectorHeight" type="range" min="30" max="95" step="1" aria-label="Inspector opening height"></div>
        <div class="settingrow settingrange"><label for="setting-previewHeight">Peek height</label><output id="previewHeight-value" for="setting-previewHeight">34%</output><input id="setting-previewHeight" type="range" min="18" max="65" step="1" aria-label="Preview opening height"></div>
        <label class="settingrow"><span>Remember resized panels</span><span class="switchwrap"><input id="setting-rememberSizes" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <div class="settingsgroup">Customize controls</div>
        <div class="settingsgroup">Inspector toolbar</div>
        <label class="settingrow"><span>Rescan</span><span class="switchwrap"><input id="setting-visible-scan" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Copy list</span><span class="switchwrap"><input id="setting-visible-copy" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Export JSON</span><span class="switchwrap"><input id="setting-visible-save" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <div class="settingsgroup">Peek</div>
        <label class="settingrow"><span>Copy resource</span><span class="switchwrap"><input id="setting-visible-previewcopy" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Inspect this page</span><span class="switchwrap"><input id="setting-visible-inspectpage" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <div class="settingsgroup">Navigation</div>
        <label class="settingrow"><span>Sources</span><span class="switchwrap"><input id="setting-visible-sourcestab" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Minimize</span><span class="switchwrap"><input id="setting-visible-minimize" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Maximize</span><span class="switchwrap"><input id="setting-visible-maximize" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <div class="settingsgroup">Resource categories</div>
        <label class="settingrow"><span>Links</span><span class="switchwrap"><input id="setting-visible-Links" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Images</span><span class="switchwrap"><input id="setting-visible-Images" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Video</span><span class="switchwrap"><input id="setting-visible-Video" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Audio</span><span class="switchwrap"><input id="setting-visible-Audio" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Scripts</span><span class="switchwrap"><input id="setting-visible-Scripts" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Styles</span><span class="switchwrap"><input id="setting-visible-Styles" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Frames</span><span class="switchwrap"><input id="setting-visible-Frames" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Metadata</span><span class="switchwrap"><input id="setting-visible-Metadata" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <label class="settingrow"><span>Network</span><span class="switchwrap"><input id="setting-visible-Network" type="checkbox" role="switch"><span class="switchtrack" aria-hidden="true"></span></span></label>
        <div class="settingsbottom"><button class="actionpill" id="settingsreset">Reset settings</button><p id="settingsnote" role="status">Saved for this website.</p></div>
      </section>

      <footer class="foot"><div class="state"><span class="miniicon">${icon('thread')}</span><span class="statecaption" id="notice">Local · browser-visible resources</span></div><span class="footbrand">Follow the thread.</span></footer>
    </section>
    <section class="preview" id="viewer" hidden role="region" aria-label="Nous Peek preview">
      <div class="grab" id="previewgrab" role="separator" tabindex="0" aria-label="Resize preview" aria-orientation="horizontal" aria-valuemin="0" aria-valuemax="100" title="Drag or use arrow keys to resize"></div>
      <header class="peekbar"><span class="peekmark">${icon('eye')}</span><div class="peektitle"><strong>Peek</strong><small id="previewkind">Follow the thread.</small></div><button class="iconbutton" id="previewcopy" aria-label="Copy preview value" title="Copy">${icon('copy')}</button><button class="actionpill" id="previewopen" aria-label="Open preview in a new tab">Open ${icon('external')}</button><button type="button" class="actionpill" id="inspectpage" hidden>Inspect this page</button><button class="iconbutton" id="previewclose" aria-label="Close preview" title="Close preview">${icon('close')}</button></header>
      <div class="previewaddress">${icon('link')}<span id="previewaddress"></span></div><div class="previewcanvas" id="previewcanvas"></div><footer class="previewfoot">${icon('thread')}<span id="previewfoot">Drag the handle to find your balance.</span></footer>
    </section>
    <div class="dragshield" id="dragshield" hidden></div>
    <div class="toast" id="toast" hidden role="status" aria-live="polite"></div>
    <div class="copydialog" id="copydialog" hidden role="dialog" aria-modal="true" aria-label="Copy text"><div class="copycard"><header><h2>Take it with you.</h2><button class="iconbutton" id="copydialogclose" aria-label="Close copy dialog">${icon('close')}</button></header><p>Touch and hold the selected text, then choose Copy.</p><textarea id="copytext" readonly aria-label="Text to copy"></textarea><button class="actionpill" id="selecttext">Select all</button></div></div>
  </div>`;
  document.documentElement.appendChild(host);
  const $ = selector => root.querySelector(selector);
  const controller = new AbortController();
  const on = (node, event, fn, options={}) => node.addEventListener(event,fn,{...options,signal:controller.signal});
  const sheet=$('.sheet'), viewer=$('#viewer'), canvas=$('#previewcanvas'), viewport=window.visualViewport;
  const categories=['All','Links','Images','Video','Audio','Scripts','Styles','Frames','Metadata','Network'];
  const categoryIcons={All:'grid',Links:'link',Images:'image',Video:'video',Audio:'audio',Scripts:'code',Styles:'style',Frames:'frame',Metadata:'info',Network:'network'};
  const colors={Links:['#436b9a','#436b9a13'],Images:['#347c5a','#347c5a13'],Video:['#80648e','#80648e13'],Audio:['#947240','#94724013'],Scripts:['#4e709b','#4e709b13'],Styles:['#836e91','#836e9113'],Frames:['#487f89','#487f8913'],Metadata:['#637d6a','#637d6a13'],Network:['#557b59','#557b5913']};
  let records=[], filtered=[], category='All', limit=80, skipped=0, mini=false, full=false, closed=false;
  let currentScan=null, inspectedFrame=null, peekFrame=null, pendingScan=null, pendingScanTimer=null;
  const inspectionHistory=[];
  let previewActive=false, previewEntry=null, previewToken=0, returnFocus=null, toastTimer=0;
  let sourceSnapshot='', sourceReturnScroll=0, readableRequest=null;
  const timers=new Set();
  const later=(fn,ms)=>{const id=setTimeout(()=>{timers.delete(id);if(!closed)fn();},ms);timers.add(id);return id;};
  const downloads=new Set();
  const vh=()=>Math.max(240,viewport?viewport.height:window.innerHeight);
  const clamp=(n,min,max)=>Math.max(min,Math.min(n,max));
  const DEFAULTS=Object.freeze({theme:'light',accent:'mint',textSize:12,density:'compact',inspectorHeight:60,previewHeight:34,wrapUrls:false,rememberSizes:true,visibility:Object.freeze({scan:true,copy:true,save:true,previewcopy:true,inspectpage:true,sourcestab:true,minimize:true,maximize:true,Links:true,Images:true,Video:true,Audio:true,Scripts:true,Styles:true,Frames:true,Metadata:true,Network:true})});
  const PREF_KEY='__nous_preferences_v1';
  function sanitizePreferences(input){
    const p=input&&typeof input==='object'?input:{}, out={...DEFAULTS,visibility:{...DEFAULTS.visibility}};
    for(const [key,allowed] of Object.entries({theme:['light','dark','system'],accent:['mint','blue','violet','amber'],density:['compact','comfortable']})){
      if(allowed.includes(p[key]))out[key]=p[key];
    }
    for(const [key,min,max] of [['textSize',11,16],['inspectorHeight',30,95],['previewHeight',18,65]]){
      const n=p[key];if(typeof n==='number'&&Number.isFinite(n))out[key]=Math.max(min,Math.min(max,Math.round(n)));
    }
    for(const key of ['wrapUrls','rememberSizes'])if(typeof p[key]==='boolean')out[key]=p[key];
    const visibility=p.visibility&&typeof p.visibility==='object'&&!Array.isArray(p.visibility)?p.visibility:{};
    for(const key of Object.keys(DEFAULTS.visibility))if(Object.prototype.hasOwnProperty.call(visibility,key)&&typeof visibility[key]==='boolean')out.visibility[key]=visibility[key];
    return out;
  }
  let storageAvailable=true, savedPreferences=null;
  try{savedPreferences=JSON.parse(window.localStorage.getItem(PREF_KEY));}catch{storageAvailable=false;}
  let preferences=sanitizePreferences(savedPreferences), settingsOpen=false, sourcesOpen=false;
  const colorQuery=window.matchMedia?window.matchMedia('(prefers-color-scheme: dark)'):null;
  function savePreferences(){
    try{window.localStorage.setItem(PREF_KEY,JSON.stringify(preferences));storageAvailable=true;}catch{storageAvailable=false;}
    $('#settingsnote').textContent=storageAvailable?'Saved for this website.':'Settings apply on this page; saving is unavailable here.';
  }
  function applyPreferences(){
    const dock=$('.dock');
    dock.dataset.theme=preferences.theme==='system'?(colorQuery&&colorQuery.matches?'dark':'light'):preferences.theme;
    dock.dataset.accent=preferences.accent;dock.dataset.density=preferences.density;
    dock.style.setProperty('--resource-size',preferences.textSize+'px');
    dock.classList.toggle('wrapurls',preferences.wrapUrls);
    applyVisibility();
  }
  function applyVisibility(){
    const visible=preferences.visibility;
    if(!visible.sourcestab&&sourcesOpen)setSourcesView(false);
    if(!visible.minimize&&mini)toggleMini();
    for(const id of ['scan','copy','save','previewcopy','sourcestab','minimize','maximize'])$('#'+id).hidden=!visible[id];
    $('#inspectpage').hidden=!visible.inspectpage||!peekFrame;
    $('.tools').hidden=settingsOpen||sourcesOpen||!(visible.scan||visible.copy||visible.save);
    for(const [name,tab] of tabs)tab.button.hidden=name!=='All'&&!visible[name];
    if(category!=='All'&&!visible[category]){category='All';render();}
  }
  function changeVisibility(key,value){
    if(!Object.prototype.hasOwnProperty.call(DEFAULTS.visibility,key)||typeof value!=='boolean')return;
    preferences=sanitizePreferences({...preferences,visibility:{...preferences.visibility,[key]:value}});
    applyVisibility();syncSettings();savePreferences();
  }
  function syncSettings(){
    for(const key of ['theme','accent','textSize','density','inspectorHeight','previewHeight']){
      $('#setting-'+key).value=String(preferences[key]);
    }
    for(const key of ['wrapUrls','rememberSizes'])$('#setting-'+key).checked=preferences[key];
    for(const key of Object.keys(DEFAULTS.visibility))$('#setting-visible-'+key).checked=preferences.visibility[key];
    $('#textSize-value').textContent=preferences.textSize+' px';
    $('#inspectorHeight-value').textContent=preferences.inspectorHeight+'%';
    $('#previewHeight-value').textContent=preferences.previewHeight+'%';
    $('#settingsnote').textContent=storageAvailable?'Saved for this website.':'Settings apply on this page; saving is unavailable here.';
  }
  function setSettingsView(open,redraw=true){
    if(open&&sourcesOpen)setSourcesView(false,false);
    settingsOpen=open;
    if(open&&previewActive)closePreview();
    $('#settingspanel').hidden=!open;$('#items').hidden=open;
    $('.tools').hidden=open||!(preferences.visibility.scan||preferences.visibility.copy||preferences.visibility.save);$('.searchline').hidden=open;$('.listhead').hidden=open;
    $('#settingstab').classList.toggle('active',open);$('#settingstab').setAttribute('aria-pressed',String(open));
    if(open)syncSettings();
    if(redraw)render();
    layout();
  }
  function showSources(){
    const serializer=new XMLSerializer();
    const serialize=node=>{
      if(node===host)return '';
      if(node.nodeType!==1||!node.contains(host))return node.outerHTML??serializer.serializeToString(node);
      const opening=node.outerHTML.match(/^<(?:[^">]|"[^"]*")*>/)[0];
      return opening+Array.from(node.childNodes,serialize).join('')+'</'+node.localName+'>';
    };
    sourceSnapshot=(document.doctype?serializer.serializeToString(document.doctype)+'\n':'')+serialize(document.documentElement);
    const code=$('#sourcecode');
    code.textContent='';
    /* Bound token creation; the rest remains complete plain text. */
    const highlighted=sourceSnapshot.slice(0,200000);
    let position=0;
    for(const match of highlighted.matchAll(/<!--[\s\S]*?-->|<![^>]*>|<\/?[a-zA-Z][^>]*>/g)){
      code.append(document.createTextNode(sourceSnapshot.slice(position,match.index)));
      const tag=document.createElement('span');tag.className='sourcetag';
      const name=match[0].match(/^<\/?[^\s>]+/)[0];
      tag.textContent=name;
      const attributes=document.createElement('span');attributes.className='sourceattr';attributes.textContent=match[0].slice(name.length);
      tag.append(attributes);code.append(tag);position=match.index+match[0].length;
    }
    code.append(document.createTextNode(sourceSnapshot.slice(position)));
  }
  function setSourcesView(open,redraw=true){
    if(open&&!preferences.visibility.sourcestab)return;
    if(open){
      if(settingsOpen)setSettingsView(false,false);
      sourceReturnScroll=$('#items').scrollTop;
      if(previewActive)closePreview();
    }
    sourcesOpen=open;
    $('#sourcespanel').hidden=!open;$('#items').hidden=open;
    $('.tools').hidden=open||!(preferences.visibility.scan||preferences.visibility.copy||preferences.visibility.save);$('.searchline').hidden=open;$('.listhead').hidden=open;
    $('#sourcestab').classList.toggle('active',open);$('#sourcestab').setAttribute('aria-pressed',String(open));
    if(open)showSources();
    else{sourceSnapshot='';$('#sourcecode').textContent='';}
    if(redraw){render();if(!open)$('#items').scrollTop=sourceReturnScroll;}
    layout();
  }
  function changePreference(key,value){
    preferences=sanitizePreferences({...preferences,[key]:value});
    if(key==='inspectorHeight'){
      const h=vh()*preferences.inspectorHeight/100;
      if(previewActive){previewReturnHeight=h;mainHeight=Math.max(h,vh()*.90);}else mainHeight=h;
      full=false;rememberedHeight=h;layout();
    }
    if(key==='previewHeight'){previewHeight=vh()*preferences.previewHeight/100;layout();}
    applyPreferences();syncSettings();
  }
  function rememberPanelSize(kind){
    if(!preferences.rememberSizes||closed)return;
    if(kind==='main'){
      if(previewActive)previewReturnHeight=parseFloat(sheet.style.height);
      preferences=sanitizePreferences({...preferences,inspectorHeight:100*(previewActive?previewReturnHeight:mainHeight)/vh()});
    }else preferences=sanitizePreferences({...preferences,previewHeight:100*previewHeight/vh()});
    savePreferences();if(settingsOpen)syncSettings();
  }

  let mainHeight=Math.round(vh()*preferences.inspectorHeight/100), previewHeight=Math.round(vh()*preferences.previewHeight/100), rememberedHeight=mainHeight, previewReturnHeight=mainHeight;
  const tabs=new Map();
  const note=message=>{
    if(closed)return;
    $('#notice').textContent=message;
    $('#toast').textContent=message;$('#toast').hidden=false;
    clearTimeout(toastTimer);timers.delete(toastTimer);
    toastTimer=later(()=>{$('#toast').hidden=true;},2200);
  };
  function closeNous(){
    if(closed)return;endReveal(false);closed=true;controller.abort();
    timers.forEach(id=>clearTimeout(id));downloads.forEach(url=>URL.revokeObjectURL(url));
    releaseMedia();host.remove();
    if(previousFocus&&previousFocus.isConnected&&typeof previousFocus.focus==='function')previousFocus.focus({preventScroll:true});
  }
  on(host,'nous:close',closeNous);
  function releaseMedia(){
    ++previewToken;
    cancelReadablePreview();
    cancelInspection();
    peekFrame=null;
    $('#inspectpage').hidden=true;
    canvas.querySelectorAll('audio,video').forEach(media=>{try{media.pause();media.removeAttribute('src');media.load();}catch{}});
    for(const child of Array.from(canvas.children)){
      if(child===inspectedFrame)child.hidden=true;else child.remove();
    }
  }
  function layout(){
    const H=vh(), top=viewport?viewport.offsetTop:0, left=viewport?viewport.offsetLeft:0;
    host.style.setProperty('top',top+'px','important');host.style.setProperty('left',left+'px','important');
    host.style.setProperty('right','auto','important');host.style.setProperty('bottom','auto','important');
    host.style.setProperty('height',H+'px','important');host.style.setProperty('width',(viewport?viewport.width:window.innerWidth)+'px','important');
    mainHeight=clamp(mainHeight,Math.min(280,H-12),H-12);
    let upper=mainHeight;
    if(previewActive&&!mini){
      const available=H-12;
      const minimumUpper=Math.min(260,H*.40);
      const minimumPeek=Math.min(150,H*.35);
      previewHeight=clamp(previewHeight,minimumPeek,Math.max(minimumPeek,available-minimumUpper));
      const total=clamp(mainHeight,previewHeight+minimumUpper,available);
      mainHeight=total;
      upper=Math.max(140,total-previewHeight);
      if(upper+previewHeight>available)upper=available-previewHeight;
      viewer.hidden=false;viewer.style.height=previewHeight+'px';sheet.style.bottom=previewHeight+'px';
    }else{viewer.hidden=true;sheet.style.bottom='0px';}
    sheet.style.height=mini?'50px':upper+'px';
    sheet.classList.toggle('split',previewActive&&!mini);sheet.classList.toggle('micro',upper<300&&!mini);
    $('#grab').setAttribute('aria-valuenow',String(Math.round((mini?50:upper)/H*100)));
    $('#previewgrab').setAttribute('aria-valuenow',String(Math.round(previewHeight/H*100)));
    $('#maximize').innerHTML=icon(full?'restore':'expand');
    $('#maximize').setAttribute('aria-label',full?'Restore inspector size':'Expand inspector');
  }
  function manualCopy(text){
    $('#copytext').value=text;$('#copydialog').hidden=false;
    $('#copytext').focus();$('#copytext').select();$('#copytext').setSelectionRange(0,text.length);
  }
  function copyText(text){
    const fallback=()=>{
      const field=document.createElement('textarea');field.value=text;
      field.style.cssText='position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;font-size:16px;';
      root.append(field);field.focus();field.select();field.setSelectionRange(0,text.length);
      let ok=false;try{ok=document.execCommand('copy');}catch{}field.remove();
      if(ok)note('Copied. Take it with you.');else manualCopy(text);
    };
    if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(text).then(()=>note('Copied. Take it with you.')).catch(()=>{if(!closed)fallback();});
    else fallback();
  }
  function scanDocument(doc,url,resourceTiming,base=doc.baseURI,depth=0){
    const records=[], seen=new Set(), discoveries=new Map();
    let skipped=0;
    function add(type,value,label,source,asText=false){
      if(value==null)return;value=String(value).trim();if(!value||value.length>6000)return;
      if(!asText){
        if(/^(javascript:|data:)/i.test(value))return;
        try{value=new URL(value,base).href;}catch{return;}
      }
      const key=type+'\u0000'+value;if(seen.has(key))return;
      if(records.length>=2500){skipped++;return;}
      seen.add(key);
      records.push({type,label:String(label||type).trim().replace(/\s+/g,' ').slice(0,150),value,source:source||'',url:!asText});
    }
    function discovered(type,value,label,source,details={},relativeTo=base){
      if(!value)return;
      try{value=new URL(String(value).trim(),relativeTo).href;}catch{return;}
      if(!/^https?:\/\//i.test(value)&&!(type==='Video'&&details.session&&/^blob:/i.test(value)))return;
      const key=type+'\u0000'+value, previous=discoveries.get(key);
      if(previous){
        if(!previous.source.split(' · ').includes(source))previous.source+=' · '+source;
        if(details.observed){previous.observed=true;previous.label=previous.label.replace('Playback unverified','Observed in page');}
        return;
      }
      const count=records.length;add(type,value,label,source);
      if(records.length>count){Object.assign(records[count],details);discoveries.set(key,records[count]);}
    }
    function video(value,source,mime='',context=false,observed=false){
      if(!value)return;
      let path;try{path=new URL(value,base).pathname;}catch{return;}
      const ext=path.match(/\.([a-z0-9]+)$/i)?.[1].toLowerCase()||'';
      if(/^(m4s|ts|cmfv|vtt|srt|jpg|jpeg|png|webp|gif|json|mp3|m4a|aac|wav|flac)$/.test(ext)||/audio\//i.test(mime)||/(?:^|[\/_-])(?:init|segment|fragment|chunk)[\w.-]*\.mp4$/i.test(path))return;
      const manifest=/^(m3u8|mpd)$/.test(ext)||/mpegurl|dash\+xml/i.test(mime);
      const format=ext||(/mpegurl/i.test(mime)?'m3u8':/dash\+xml/i.test(mime)?'mpd':mime.replace(/^video\//i,''));
      const session=/^blob:/i.test(value);
      if(session&&!observed)return;
      if(!manifest&&!/^(mp4|m4v|mov|webm|ogv|ogg|mkv|avi|3gp|mpeg|mpg)$/.test(ext)&&!/^video\//i.test(mime)&&!context)return;
      const status=session?'Session only':observed?'Observed in page':'Playback unverified';
      discovered('Video',value,(manifest?'Manifest · compatible player required':'Direct video candidate')+(format?' · '+format.toUpperCase():'')+' · '+status,source,{format,manifest,session,observed});
    }
    function font(value,source,description='',format='',relativeTo=base){
      let path;try{path=new URL(value,relativeTo).pathname;}catch{return;}
      format=format||path.match(/\.(woff2?|ttf|otf|ttc|otc|eot)$/i)?.[1]||'';
      discovered('Styles',value,'Font'+(format?' · '+format.toUpperCase():'')+(description?' · '+description:''),source,{font:true,format},relativeTo);
    }
    const all=(selector,fn)=>doc.querySelectorAll(selector).forEach(fn);
    const attrs=(el,type,fields,label)=>fields.forEach(field=>{const value=el.getAttribute(field);if(value)add(type,value,label||el.tagName.toLowerCase(),el.tagName.toLowerCase()+'['+field+']');});
    all('a[href],area[href]',el=>attrs(el,'Links',['href'],el.textContent.trim()||el.getAttribute('aria-label')||'Link'));
    all('form[action]',el=>attrs(el,'Links',['action'],'Form action'));
    all('img',el=>{attrs(el,'Images',['src','data-src','data-original'],el.alt||'Image');if(el.currentSrc)add('Images',el.currentSrc,el.alt||'Image','img.currentSrc');});
    function addSrcset(el,attribute,source){
      const set=el.getAttribute(attribute)||'';
      let position=0;
      while(position<set.length){
        while(position<set.length&&/[\s,]/.test(set[position]))position++;
        const start=position;while(position<set.length&&!/\s/.test(set[position]))position++;
        let url=set.slice(start,position);
        if(/,$/.test(url))url=url.replace(/,+$/,'');
        else while(position<set.length&&set[position]!==',')position++;
        if(url)add('Images',url,'Responsive image',source);
      }
    }
    all('img[srcset],source[srcset]',el=>addSrcset(el,'srcset','srcset'));
    all('video',el=>{const observed=!!el.currentSrc&&el.readyState>=2&&!el.error;['src','data-src'].forEach(name=>video(el.getAttribute(name),'video['+name+']',el.getAttribute('type')||'',true));attrs(el,'Images',['poster'],'Video poster');video(el.currentSrc,'video.currentSrc','',true,observed);});
    all('audio',el=>{attrs(el,'Audio',['src','data-src'],'Audio');if(el.currentSrc)add('Audio',el.currentSrc,'Audio','audio.currentSrc');});
    all('source[src]',el=>{if(el.closest('video'))video(el.getAttribute('src'),'video source',el.getAttribute('type')||'',true);else attrs(el,el.closest('audio')?'Audio':'Images',['src'],'Source');});
    all('script[src]',el=>attrs(el,'Scripts',['src'],'JavaScript'));
    const linkElements=doc.querySelectorAll('link[href],link[imagesrcset]');
    linkElements.forEach(el=>{const rel=el.rel||'link';add(/stylesheet/i.test(rel)?'Styles':/icon|image/i.test(rel)?'Images':/modulepreload/i.test(rel)?'Scripts':'Links',el.getAttribute('href'),rel,'link[rel]');});
    all('iframe[src],frame[src],embed[src],object[data]',el=>attrs(el,'Frames',el.tagName.toLowerCase()==='object'?['data']:['src'],el.title||'Embedded content'));
    all('[style]',el=>{for(const match of (el.getAttribute('style')||'').matchAll(/url\(\s*(['"]?)(.*?)\1\s*\)/gi))add('Images',match[2],'Inline background','style=url()');});
    all('meta[content]',el=>add('Metadata',el.content,el.getAttribute('property')||el.getAttribute('name')||el.getAttribute('http-equiv')||'meta','meta',true));
    add('Metadata',doc.title||doc.querySelector('title')?.textContent||'(untitled)','Page title','document.title',true);
    add('Metadata',url,'Page address','location',true);
    if(resourceTiming?.getEntriesByType)resourceTiming.getEntriesByType('resource').forEach(entry=>add('Network',entry.name,entry.initiatorType||'Resource','Performance API'));
    if(records.length<2500){
      const preloadTypes={image:'Images',script:'Scripts',style:'Styles',video:'Video',audio:'Audio'};
      linkElements.forEach(el=>{
        const rel=el.rel||'', as=(el.getAttribute('as')||'').toLowerCase();
        if(!/(?:^|\s)preload(?:\s|$)/i.test(rel)||!Object.prototype.hasOwnProperty.call(preloadTypes,as))return;
        if(as==='video')video(el.getAttribute('href'),'Video preload',el.getAttribute('type')||'',true);else add(preloadTypes[as],el.getAttribute('href'),rel,'link[rel]');
        if(as==='image')addSrcset(el,'imagesrcset','link[imagesrcset]');
      });
    }
    if(records.length<2500){
      /* Read declarations only; inaccessible CSSOM rules are isolated per sheet. */
      const sheets=new Set();
      function readSheet(sheet,parentBase=base){
        if(!sheet||sheets.has(sheet))return;sheets.add(sheet);
        const sheetBase=sheet.href||parentBase;
        let rules;try{rules=sheet.cssRules;}catch{return;}
        readRules(rules,sheetBase);
      }
      function readRules(rules,sheetBase){
        for(const rule of Array.from(rules||[])){
          if(records.length>=2500)break;
          if(rule.styleSheet)readSheet(rule.styleSheet,sheetBase);
          if(rule.type===5&&rule.style){
            const style=rule.style, description=['font-family','font-weight','font-style'].map(key=>style.getPropertyValue(key)).filter(Boolean).join(' · ');
            for(const match of style.getPropertyValue('src').matchAll(/url\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*?))\s*\)\s*(?:format\(\s*['"]?([^)'"\s]+)['"]?\s*\))?/gi))font(match[1]||match[2]||match[3],'@font-face',description,match[4]||'',sheetBase);
          }else if(rule.cssRules)readRules(rule.cssRules,sheetBase);
        }
      }
      Array.from(doc.styleSheets||[]).forEach(sheet=>readSheet(sheet));
      linkElements.forEach(el=>{
        const href=el.getAttribute('href'), mime=el.getAttribute('type')||'';
        if(/(?:^|\s)preload(?:\s|$)/i.test(el.rel||'')&&((el.getAttribute('as')||'').toLowerCase()==='font'||/font|woff|opentype/i.test(mime)))font(href,'Font preload','',mime.replace(/^(?:font\/|application\/(?:x-font-|font-)?)/i,'').replace(/^vnd.ms-fontobject$/i,'eot'));
        video(href,'Link',mime,(el.getAttribute('as')||'')==='video');
      });
      all('*',el=>{
        if(records.length>=2500)return;
        for(const attr of Array.from(el.attributes||[])){
          if(/^(?:href|src|data-)/i.test(attr.name)){
            const context=(el.tagName.toLowerCase()==='video'||!!el.closest('video')||/video|movie|hls|dash|manifest/i.test(attr.name))&&! /poster|thumb|subtitle|audio/i.test(attr.name);
            if(el.tagName.toLowerCase()!=='audio'&&!el.closest('audio')&&!/poster|thumb|subtitle|audio/i.test(attr.name))video(attr.value,el.tagName.toLowerCase()+'['+attr.name+']',el.getAttribute('type')||'',context);
            if(/^data-/i.test(attr.name)&&/^[\[{]/.test(attr.value.trim()))readJSON(attr.value,'Data JSON');
          }
        }
      });
      function readJSON(text,source){
        if(text.length>1000000)return;
        let data;try{data=JSON.parse(text);}catch{return;}
        let visited=0;
        function walk(value,context=false,depth=0){
          if(++visited>10000||depth>20||records.length>=2500)return;
          if(Array.isArray(value)){value.forEach(item=>walk(item,context,depth+1));return;}
          if(!value||typeof value!=='object')return;
          const mime=typeof value.type==='string'?value.type:typeof value.mimeType==='string'?value.mimeType:'';
          const player=context||/^video\//i.test(mime)||/VideoObject/i.test(value['@type']||'');
          for(const [key,item] of Object.entries(value)){
            if(/poster|thumb|subtitle|caption|audio|image|track/i.test(key))continue;
            const next=player||/video|movie|sources|playlist|hls|dash|manifest/i.test(key);
            if(typeof item==='string'&&(/^(?:https?:|\/|\.\/|\.\.\/)/i.test(item)||/\.(?:mp4|m3u8|mpd|webm)(?:[?#]|$)/i.test(item)))video(item,source,mime,next&&/url|src|file|contentUrl|video|hls|dash|manifest/i.test(key));
            else if(typeof item==='object')walk(item,next,depth+1);
          }
        }
        walk(data);return true;
      }
      all('script:not([src])',el=>{
        const text=el.textContent||'';if(readJSON(text,'Embedded JSON'))return;
        /* Literal URLs in accessible configuration text; never evaluate page code. */
        if(text.length<=1000000){const assigned=text.match(/(?:^|[;\n])\s*(?:(?:var|let|const)\s+|window\.)?[\w.$]+\s*=\s*([\s\S]*?)\s*;?\s*$/);if(assigned&&readJSON(assigned[1],'Player configuration'))return;}
        if(text.length<=1000000)for(const match of text.replace(/\\\//g,'/').matchAll(/["']((?:https?:\/\/|\/|\.\.\/|\.\/)[^"'\s<>]+)["']/g))video(match[1].replace(/\\\//g,'/'),'Embedded URL');
      });
      if(resourceTiming?.getEntriesByType)resourceTiming.getEntriesByType('resource').forEach(entry=>{
        video(entry.name,'Performance API',entry.contentType||'');
        if(/\.(?:woff2?|ttf|otf|ttc|otc|eot)(?:[?#]|$)/i.test(entry.name)||/font|woff|opentype/i.test(entry.contentType||''))font(entry.name,'Performance API (recorded resource; rendering unverified)','',(entry.contentType||'').replace(/^(?:font\/|application\/(?:x-font-|font-)?)/i,''));
      });
    }
    if(depth<2&&records.length<2500){
      Array.from(doc.querySelectorAll('iframe,frame')).slice(0,20).forEach(frame=>{
        let child,timing;try{child=frame.contentDocument;if(!child||!/^https?:/i.test(child.URL))return;timing=frame.contentWindow?.performance;}catch{return;}
        const scan=scanDocument(child,child.URL,timing,child.baseURI,depth+1);
        scan.records.filter(entry=>entry.type==='Video'||entry.font).forEach(entry=>discovered(entry.type,entry.value,entry.label,'Embedded player · '+entry.source,entry));
      });
    }
    return {url,records,skipped};
  }
  function livePage(frame){
    if(!frame?.isConnected)return null;
    try{
      const doc=frame.contentDocument;
      if(!doc||doc.readyState==='loading'||! /^(https?:|blob:)/i.test(doc.URL))return null;
      if(!/^(text\/html|application\/xhtml\+xml)$/i.test(doc.contentType))return null;
      return {doc,url:doc.URL,timing:frame.contentWindow.performance};
    }catch{return null;}
  }
  function previewUrl(){
    return livePage(peekFrame)?.url||previewEntry?.value||'';
  }
  function updatePreviewAddress(url){
    const address=$('#previewaddress');
    address.textContent=url;
    address.title=url;
    $('#previewopen').disabled=!/^https?:\/\//i.test(url);
  }
  function setScan(scan,frame=null){
    if(inspectedFrame&&inspectedFrame!==frame&&inspectedFrame!==peekFrame)inspectedFrame.remove();
    inspectedFrame=frame;
    currentScan=scan;
    records=scan.records;
    skipped=scan.skipped;
    const url=new URL(scan.url);
    const site=$('#site');
    site.textContent=url.protocol==='blob:'?'Local preview':url.host+(url.pathname==='/'?'':url.pathname)+url.search+url.hash;
    site.title=scan.url;
    $('#total').textContent=records.length.toLocaleString()+' found';
    $('#inspectback').hidden=!inspectionHistory.length;
    sheet.classList.toggle('has-history',inspectionHistory.length>0);
  }
  function collect(){
    setScan({...scanDocument(document,location.href,performance),mode:'host'});
  }
  function scanMessage(mode,action){
    const html=mode==='html';
    const onlyDetails=records.every(entry=>entry.source==='document.title'||entry.source==='location');
    return (html?'HTML ':'Live ')+action+' complete · '+(onlyDetails?'page details only':records.length+' found')+'.'+(html?' No live network data.':'');
  }
  function waitForPeek(frame,signal){
    if(!frame||frame.dataset.loading!=='true'||signal.aborted)return Promise.resolve();
    return new Promise(resolve=>{
      const timeout=setTimeout(finish,2500);
      function finish(){
        clearTimeout(timeout);
        frame.removeEventListener('load',finish);
        signal.removeEventListener('abort',finish);
        resolve();
      }
      frame.addEventListener('load',finish,{once:true});
      signal.addEventListener('abort',finish,{once:true});
    });
  }
  async function loadInspection(url,frame,signal){
    const live=livePage(frame);
    if(live?.url===url){
      return {scan:{...scanDocument(live.doc,live.url,live.timing),mode:'live'},frame};
    }
    if(!/^https?:\/\//i.test(url))throw new Error('Page unavailable');
    const response=await fetch(url,{credentials:'same-origin',referrerPolicy:'no-referrer',signal});
    if(!response.ok||! /^(text\/html|application\/xhtml\+xml)(?:\s*;|$)/i.test(response.headers.get('content-type')||'')){
      throw new Error('HTML unavailable');
    }
    const requested=new URL(url), fetched=new URL(response.url||url);
    requested.hash='';fetched.hash='';
    if(response.redirected||requested.href!==fetched.href)throw new Error('unverified-redirect');
    const html=await response.text();
    const template=document.createElement('template');
    template.innerHTML=html;
    const doc=template.content;
    const address=url;
    let base=address;
    const declaredBase=doc.querySelector('base[href]')?.getAttribute('href');
    if(declaredBase)try{
      const resolved=new URL(declaredBase,address);
      if(/^https?:$/.test(resolved.protocol))base=resolved.href;
    }catch{}
    return {scan:{...scanDocument(doc,address,null,base),mode:'html'},frame:null};
  }
  function cancelInspection(){
    if(pendingScanTimer!==null)clearTimeout(pendingScanTimer);
    pendingScanTimer=null;
    if(pendingScan)pendingScan.abort();
    pendingScan=null;
    $('#inspectpage').disabled=false;
    $('#scan').disabled=false;
  }
  async function runInspection(read,apply,failure){
    cancelInspection();
    const request=new AbortController();
    pendingScan=request;
    $('#inspectpage').disabled=true;
    $('#scan').disabled=true;
    pendingScanTimer=setTimeout(()=>{
      if(pendingScan===request&&!closed){
        cancelInspection();
        failure(new Error('timeout'));
      }
    },12000);
    try{
      const result=await read(request.signal);
      if(pendingScan!==request||request.signal.aborted||closed)return;
      apply(result);
    }catch(error){
      if(pendingScan===request&&!closed)failure(error);
    }finally{
      if(pendingScan===request)cancelInspection();
    }
  }
  function inspectPreview(){
    const frame=peekFrame;
    if(!frame)return;
    return runInspection(async signal=>{
      await waitForPeek(frame,signal);
      if(signal.aborted)throw new Error('Cancelled');
      const url=previewUrl();
      updatePreviewAddress(url);
      return loadInspection(url,frame,signal);
    },({scan,frame:sourceFrame})=>{
      const samePage=scan.url===currentScan.url;
      const scroll=$('#items').scrollTop;
      if(!samePage){
        inspectionHistory.push({scan:currentScan,category,query:$('#find').value,limit,scroll:$('#items').scrollTop});
        if(inspectionHistory.length>5)inspectionHistory.shift();
      }
      setScan(scan,sourceFrame);
      if(!samePage){
        category='All';
        limit=80;
        $('#find').value='';
        $('#tabs').scrollLeft=0;
      }
      render();
      $('#items').scrollTop=samePage?scroll:0;
      const message=scanMessage(scan.mode,'scan');
      $('#previewfoot').textContent=message;
      note(message);
    },error=>{
      const redirected=error?.message==='unverified-redirect';
      const timedOut=error?.message==='timeout';
      $('#previewfoot').textContent=redirected?'Redirect destination could not be verified. Open the page and run Nous there.':timedOut?'Inspection timed out. Open the page and run Nous there.':'Browser access blocked or page unavailable. Open it and run Nous there.';
      note(redirected?'Could not verify redirect.':timedOut?'Inspection timed out.':'Could not inspect this page.');
    });
  }
  function rescanCurrent(){
    const url=currentScan.url;
    const report=message=>{
      if(peekFrame&&previewUrl()===url)$('#previewfoot').textContent=message;
      note(message);
    };
    if(currentScan.mode==='host'){
      cancelInspection();
      const scroll=$('#items').scrollTop;
      collect();
      render();
      $('#items').scrollTop=scroll;
      report(scanMessage('live','rescan'));
      return;
    }
    const frame=livePage(inspectedFrame)?.url===url?inspectedFrame:peekFrame;
    return runInspection(signal=>loadInspection(url,frame,signal),({scan,frame:sourceFrame})=>{
      const scroll=$('#items').scrollTop;
      setScan(scan,sourceFrame);
      render();
      $('#items').scrollTop=scroll;
      report(scanMessage(scan.mode,'rescan'));
    },error=>report(error?.message==='unverified-redirect'?'Could not verify redirect.':error?.message==='timeout'?'Rescan timed out.':'Rescan unavailable. Open the page and run Nous there.'));
  }
  function backInspection(){
    const previous=inspectionHistory.pop();
    if(!previous)return;
    cancelInspection();
    const frame=livePage(peekFrame)?.url===previous.scan.url?peekFrame:null;
    setScan(previous.scan,frame);
    category=previous.category;
    limit=previous.limit;
    $('#find').value=previous.query;
    render();
    $('#items').scrollTop=previous.scroll;
    if(peekFrame)$('#previewfoot').textContent='Tap Inspect this page to scan this preview.';
    note('Returned to previous inspection.');
  }

  function domain(entry){try{return new URL(entry.value).hostname.replace(/^www\./,'')||entry.source;}catch{return entry.source;}}
  function revealReferences(el,url){
    const methods=[];
    const same=value=>{try{return !!value&&new URL(value,el.ownerDocument.baseURI).href===url;}catch{return false;}};
    const tag=el.localName;
    if(/^(img|video|audio)$/.test(tag)&&same(el.currentSrc))methods.push('currentSrc');
    for(const attr of el.attributes){
      if(attr.value.length>6000)continue;
      if(/^(href|src|action|poster|data)$/.test(attr.name)||(/^data-/.test(attr.name)&&(/src|url|href|poster|video|image|movie|file|stream|background|original|lazy/i.test(attr.name)||/^(https?:|blob:|\/|\.\.?\/)/i.test(attr.value)))){
        if(same(attr.value))methods.push(tag==='source'?'source['+attr.name+']':attr.name);
      }
      if(/^(srcset|data-srcset)$/.test(attr.name)){
        /* Use the scanner's srcset token boundaries, including data URL exclusion. */
        let position=0;
        while(position<attr.value.length){
          while(position<attr.value.length&&/[\s,]/.test(attr.value[position]))position++;
          const start=position;while(position<attr.value.length&&!/\s/.test(attr.value[position]))position++;
          let value=attr.value.slice(start,position);
          if(/,$/.test(value))value=value.replace(/,+$/,'');else while(position<attr.value.length&&attr.value[position]!==',')position++;
          if(same(value)){methods.push(tag==='source'?'source['+attr.name+']':attr.name);break;}
        }
      }
      if(attr.name==='style')for(const match of attr.value.matchAll(/url\(\s*(['"]?)(.*?)\1\s*\)/gi))if(same(match[2])){methods.push('style url()');break;}
    }
    return methods;
  }
  function revealElement(el){
    if(el.localName==='source')return el.closest('video,audio')||el.closest('picture')?.querySelector('img')||el;
    return el;
  }
  function findRevealMatches(doc,url,frames=[]){
    const matches=[],seen=new Map();let visited=0,frameCount=0,limited=false;
    function walk(page,chain,depth){
      const walker=page.createTreeWalker(page.documentElement,1);
      for(let el=walker.currentNode;el;el=walker.nextNode()){
        if(++visited>20000||matches.length>=100){limited=true;break;}
        if(el===host)continue;
        const methods=revealReferences(el,url);
        if(methods.length){
          const element=revealElement(el),previous=seen.get(element);
          if(previous)previous.references.push(el);
          else{const match={element,references:[el],frames:chain};seen.set(element,match);matches.push(match);}
        }
        if(/^(iframe|frame)$/.test(el.localName)&&depth<2&&frameCount<20){
          let child;try{child=el.contentDocument;}catch{continue;}
          if(child?.documentElement){frameCount++;walk(child,[...chain,el],depth+1);}
        }else if(/^(iframe|frame)$/.test(el.localName))limited=true;
      }
    }
    walk(doc,frames,0);return {matches,limited};
  }
  function revealGeometry(match){
    const el=match.element;
    if(!el.isConnected)return {state:'Removed from page'};
    if(/^(script|style|link|meta|head|base|source)$/.test(el.localName))return {state:'Declaration only'};
    function bounds(node){
      if(!node.getClientRects().length)return null;
      let {left,top,right,bottom}=node.getBoundingClientRect();
      if(right<=left||bottom<=top)return null;
      for(let parent=node;parent;parent=parent.parentElement){
        const style=parent.ownerDocument.defaultView.getComputedStyle(parent);
        if(style.visibility==='hidden'||style.visibility==='collapse'||Number(style.opacity)===0||style.contentVisibility==='hidden')return null;
        if(parent!==node&&/hidden|clip|scroll|auto/.test(style.overflowX+' '+style.overflowY)){
          const rect=parent.getBoundingClientRect(),sx=parent.offsetWidth?rect.width/parent.offsetWidth:1,sy=parent.offsetHeight?rect.height/parent.offsetHeight:1;
          const x=rect.left+parent.clientLeft*sx,y=rect.top+parent.clientTop*sy;
          if(/hidden|clip|scroll|auto/.test(style.overflowX)){left=Math.max(left,x);right=Math.min(right,x+parent.clientWidth*sx);}
          if(/hidden|clip|scroll|auto/.test(style.overflowY)){top=Math.max(top,y);bottom=Math.min(bottom,y+parent.clientHeight*sy);}
        }
      }
      return {left,top,right,bottom};
    }
    const box=bounds(el),frameBoxes=match.frames.map(bounds);
    if(!box||frameBoxes.some(box=>!box))return {state:'Hidden'};
    let {left,top,right,bottom}=box;
    for(let index=match.frames.length-1;index>=0;index--){
      const frame=match.frames[index],clip=frameBoxes[index];
      const rect=frame.getBoundingClientRect(),sx=frame.offsetWidth?rect.width/frame.offsetWidth:1,sy=frame.offsetHeight?rect.height/frame.offsetHeight:1;
      const x=rect.left+frame.clientLeft*sx,y=rect.top+frame.clientTop*sy;
      left=x+left*sx;right=x+right*sx;top=y+top*sy;bottom=y+bottom*sy;
      left=Math.max(left,x,clip.left);top=Math.max(top,y,clip.top);right=Math.min(right,x+frame.clientWidth*sx,clip.right);bottom=Math.min(bottom,y+frame.clientHeight*sy,clip.bottom);
    }
    const x=viewport?.offsetLeft||0,y=viewport?.offsetTop||0;
    left=Math.max(left,x);top=Math.max(top,y);right=Math.min(right,x+host.clientWidth);bottom=Math.min(bottom,y+vh());
    return right>left&&bottom>top?{state:'Visible reference',left:left-x,top:top-y,width:right-left,height:bottom-top}:{state:'Off screen or clipped'};
  }
  let revealSession=null;
  function ensureRevealUI(){
    if($('#revealhud'))return;
    const content=document.createElement('div');content.innerHTML=`<div class="revealring" id="revealring" hidden aria-hidden="true"></div>
    <section class="revealhud" id="revealhud" hidden role="region" aria-label="Reveal on page">
      <header class="revealheading"><strong>Reveal on page</strong><button type="button" class="iconbutton" id="revealagain" aria-label="Highlight again" title="Highlight again">${icon('target')}</button><button type="button" class="actionpill" id="revealdone">Done</button></header>
      <span id="revealurl"></span><div id="revealstatus" role="status" aria-live="polite"></div>
      <div class="revealcontrols"><button type="button" class="actionpill" id="revealprev" aria-label="Previous reference">${icon('back')}</button><span id="revealcount"></span><button type="button" class="actionpill" id="revealnext" aria-label="Next reference">${icon('arrow')}</button><button type="button" class="actionpill" id="revealjump" hidden>Scroll to</button></div>
    </section>
`;
    $('.dock').append(...content.childNodes);
    on($('#revealdone'),'click',()=>endReveal());
    on($('#revealprev'),'click',()=>showRevealMatch(-1));on($('#revealnext'),'click',()=>showRevealMatch(1));
    on($('#revealagain'),'click',()=>showRevealMatch());on($('#revealjump'),'click',jumpReveal);
    on($('#revealhud'),'keydown',event=>{if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();showRevealMatch(event.key==='ArrowLeft'?-1:1);}});
  }
  function stopRevealHighlight(){
    if(!revealSession)return;
    clearTimeout(revealSession.timer);revealSession.tracking?.abort();
    if(revealSession.raf)cancelAnimationFrame(revealSession.raf);
    revealSession.raf=0;$('#revealring').hidden=true;
  }
  function endReveal(focus=true){
    if(!revealSession)return;
    const session=revealSession;stopRevealHighlight();session.controller.abort();revealSession=null;
    session.frame?.classList.remove('reveal-document');$('.dock').classList.remove('revealing','revealing-frame');
    $('#revealhud').hidden=true;
    if(focus&&session.trigger?.isConnected)session.trigger.focus({preventScroll:true});
  }
  function paintReveal(){
    const session=revealSession;if(!session)return;
    const match=session.matches[session.index],ring=$('#revealring');ring.hidden=true;
    if(!match)return;
    const evidence=(match.element.isConnected?revealReferences(match.element,session.entry.value):[]).concat(match.references.filter(el=>el.isConnected&&revealElement(el)===match.element).flatMap(el=>revealReferences(el,session.entry.value)));
    const geometry=evidence.length?revealGeometry(match):{state:match.element.isConnected?'Reference changed':'Removed from page'};
    const methods=[...new Set(evidence)];
    $('#revealstatus').textContent=geometry.state+' · <'+match.element.localName+'>'+(methods.length?' · '+methods.join(', '):'');
    $('#revealjump').hidden=geometry.state!=='Off screen or clipped';
    if(geometry.width){
      ring.style.cssText='left:'+geometry.left+'px;top:'+geometry.top+'px;width:'+geometry.width+'px;height:'+geometry.height+'px;';ring.hidden=false;
    }
  }
  function showRevealMatch(step=0){
    const session=revealSession;if(!session)return;
    stopRevealHighlight();
    if(session.matches.length)session.index=(session.index+step+session.matches.length)%session.matches.length;
    $('#revealcount').textContent=session.matches.length?(session.index+1)+' / '+session.matches.length+(session.limited?' (limit)':''):'0 references';
    for(const id of ['revealprev','revealnext'])$('#'+id).disabled=session.matches.length<2;
    $('#revealagain').disabled=!session.matches.length;
    $('#revealjump').hidden=true;
    if(!session.matches.length){$('#revealstatus').textContent=session.limited?'No element match in the bounded search.':'No element match · it may be declared, timing-only or in a restricted frame.';return;}
    paintReveal();
    session.tracking=new AbortController();
    const update=()=>{if(!session.raf)session.raf=requestAnimationFrame(()=>{session.raf=0;if(revealSession===session)paintReveal();});};
    for(const win of new Set([window,...session.matches[session.index].frames.map(frame=>frame.ownerDocument.defaultView),session.matches[session.index].element.ownerDocument.defaultView])){
      win.addEventListener('scroll',update,{capture:true,passive:true,signal:session.tracking.signal});
      win.addEventListener('resize',update,{passive:true,signal:session.tracking.signal});
      if(win.visualViewport)for(const event of ['resize','scroll'])win.visualViewport.addEventListener(event,update,{passive:true,signal:session.tracking.signal});
    }
    session.timer=setTimeout(stopRevealHighlight,2400);
  }
  function startReveal(entry,trigger){
    if(closed)return;
    endReveal(false);
    let page=document,frame=null;
    if(currentScan.mode!=='host'){
      frame=inspectedFrame;
      const live=livePage(frame);
      if(!live||live.url!==currentScan.url){note('Reveal needs the live page. Open it and run Nous there.');return;}
      page=live.doc;
    }
    ensureRevealUI();cancelInspection();
    const found=findRevealMatches(page,entry.value,frame?[frame]:[]);
    revealSession={...found,entry,trigger,frame,index:0,controller:new AbortController()};
    $('.dock').classList.add('revealing');$('.dock').classList.toggle('revealing-frame',!!frame);frame?.classList.add('reveal-document');
    $('#revealhud').hidden=false;$('#revealurl').textContent=entry.value;$('#revealurl').title=entry.value;
    const visible=found.matches.findIndex(match=>revealGeometry(match).width);if(visible>=0)revealSession.index=visible;
    for(const win of new Set([window,page.defaultView,...found.matches.flatMap(match=>match.frames.map(parent=>parent.ownerDocument.defaultView))])){
      win.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();endReveal();}},{capture:true,signal:revealSession.controller.signal});
      win.addEventListener('pagehide',()=>endReveal(false),{once:true,signal:revealSession.controller.signal});
    }
    for(const parent of new Set(found.matches.flatMap(match=>match.frames)))parent.addEventListener('load',()=>endReveal(),{once:true,signal:revealSession.controller.signal});
    showRevealMatch();$('#revealdone').focus({preventScroll:true});
  }
  function jumpReveal(){
    const match=revealSession?.matches[revealSession.index];if(!match)return;
    paintReveal();if($('#revealjump').hidden)return;
    for(const el of [...match.frames,match.element])el.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'});
    showRevealMatch();
  }
  function render(){
    if(revealSession)endReveal(false);
    if(category!=='All'&&!preferences.visibility[category])category='All';
    const q=$('#find').value.toLowerCase().trim();
    filtered=records.filter(entry=>(category==='All'||entry.type===category)&&(!q||(entry.value+' '+entry.label+' '+entry.source).toLowerCase().includes(q)));
    $('#count').textContent=(q?filtered.length+' MATCH'+(filtered.length===1?'':'ES'):category==='All'?'ALL RESOURCES':category.toUpperCase()+' · '+filtered.length)+(skipped?' · LIMIT 2,500':'');
    const counts=new Map();for(const entry of records)counts.set(entry.type,(counts.get(entry.type)||0)+1);
    for(const c of categories){const tab=tabs.get(c);tab.button.hidden=c!=='All'&&!preferences.visibility[c];tab.button.classList.toggle('active',c===category&&!settingsOpen&&!sourcesOpen);tab.button.setAttribute('aria-pressed',String(c===category&&!settingsOpen&&!sourcesOpen));tab.count.textContent=String(c==='All'?records.length:counts.get(c)||0);}
    const list=$('#items');list.replaceChildren();
    if(!filtered.length){
      const empty=document.createElement('div');empty.className='empty';empty.innerHTML='<span class="avatar">'+icon('search')+'</span><strong>No threads here yet.</strong><p>Try a shorter search, another category, or rescan after the page loads.</p>';list.append(empty);return;
    }
    const fragment=document.createDocumentFragment();
    for(const entry of filtered.slice(0,limit)){
      const row=document.createElement('div');row.className='item';row.classList.toggle('selected',!!previewEntry&&entry.type===previewEntry.type&&entry.value===previewEntry.value);
      const color=colors[entry.type]||colors.Links;row.style.setProperty('--row-color',color[0]);row.style.setProperty('--row-bg',color[1]);
      const button=document.createElement('button');button.type='button';button.className='resource';button.setAttribute('aria-label','Peek: '+entry.label);button.setAttribute('aria-pressed',String(row.classList.contains('selected')));
      const avatar=document.createElement('span');avatar.className='avatar';avatar.innerHTML=icon(categoryIcons[entry.type]);
      const main=document.createElement('span');main.className='itemmain';
      const eyebrow=document.createElement('span');eyebrow.className='eyebrow';
      const type=document.createElement('span');type.className='type';type.textContent=entry.type;
      const sep=document.createElement('span');sep.className='sep';
      const origin=document.createElement('span');origin.textContent=entry.url?domain(entry):entry.source;
      eyebrow.append(type,sep,origin);
      const label=document.createElement('span');label.className='label';label.textContent=entry.label;
      const value=document.createElement('div');value.className='val';if(entry.font||entry.type==='Video')value.style.cssText='white-space:normal;overflow-wrap:anywhere;';value.textContent=entry.value;value.title=entry.value;
      main.append(eyebrow,label,value);button.append(avatar,main);button.onclick=()=>showPreview(entry,button);
      const copy=document.createElement('button');copy.type='button';copy.className='copyitem';copy.innerHTML=icon('copy');copy.setAttribute('aria-label','Copy '+entry.label);copy.onclick=()=>copyText(entry.value);
      row.append(button,copy);
      if(entry.url&&/^(https?:|blob:)/i.test(entry.value)){
        const reveal=document.createElement('button');reveal.type='button';reveal.className='copyitem revealitem';reveal.textContent='Reveal';reveal.title='Reveal on page';reveal.setAttribute('aria-label','Reveal on page: '+entry.label);reveal.onclick=()=>startReveal(entry,reveal);row.append(reveal);
      }
      fragment.append(row);
    }
    list.append(fragment);
    if(filtered.length>limit){const more=document.createElement('button');more.className='more';more.textContent='Show '+Math.min(80,filtered.length-limit)+' more';more.onclick=()=>{const position=list.scrollTop;limit+=80;render();list.scrollTop=position;};list.append(more);}
  }
  for(const c of categories){
    const button=document.createElement('button');button.type='button';button.className='tab';button.innerHTML=c==='All'?icon('grid'):'';
    const title=document.createElement('span');title.textContent=c;const count=document.createElement('span');count.className='num';button.append(title,count);
    button.onclick=()=>{if(settingsOpen)setSettingsView(false,false);if(sourcesOpen)setSourcesView(false,false);category=c;limit=80;render();$('#items').scrollTop=0;button.scrollIntoView({block:'nearest',inline:'nearest'});};
    $('#tabs').append(button);tabs.set(c,{button,count});
  }
  function updateSelected(){
    const shown=filtered.slice(0,limit);$('#items').querySelectorAll('.item').forEach((row,i)=>{const entry=shown[i];const selected=!!entry&&!!previewEntry&&entry.type===previewEntry.type&&entry.value===previewEntry.value;row.classList.toggle('selected',selected);row.querySelector('.resource').setAttribute('aria-pressed',String(selected));});
  }
  function cancelReadablePreview(){
    if(!readableRequest)return;
    clearTimeout(readableRequest.timer);readableRequest.controller.abort();readableRequest=null;
  }
  async function readablePreview(frame,url,token,blocked=false){
    if(closed||token!==previewToken||peekFrame!==frame||pendingScan||frame.dataset.textPreview)return;
    if($('#previewfoot').textContent!==frame.dataset.previewStatus)return;
    let sameOrigin=false;
    try{sameOrigin=new URL(url).origin===location.origin&&/^https?:/.test(url);}catch{}
    if(!sameOrigin){if(blocked)$('#previewfoot').textContent='This site blocks the embedded preview. Use Open.';return;}
    if(!blocked){
      try{if(frame.contentDocument&&frame.contentDocument.URL!=='about:blank')return;}catch{}
    }
    frame.dataset.textPreview='true';
    cancelReadablePreview();
    const request={controller:new AbortController(),timer:null,timedOut:false};
    readableRequest=request;
    const message='Reading text preview…';$('#previewfoot').textContent=message;
    const current=()=>!closed&&token===previewToken&&peekFrame===frame&&readableRequest===request&&!pendingScan&&$('#previewfoot').textContent===message;
    request.timer=setTimeout(()=>{request.timedOut=true;request.controller.abort();},12000);
    try{
      const response=await fetch(url,{credentials:'same-origin',mode:'same-origin',redirect:'error',referrerPolicy:'no-referrer',signal:request.controller.signal});
      if(!response.ok||!/^text\/html(?:\s*;|$)/i.test(response.headers.get('content-type')||''))throw Error('unavailable');
      const maximum=2*1024*1024;
      if(Number(response.headers.get('content-length'))>maximum)throw Error('too-large');
      const reader=response.body.getReader(),decoder=new TextDecoder();
      let bytes=0,html='';
      try{
        while(true){const chunk=await reader.read();if(chunk.done)break;bytes+=chunk.value.byteLength;if(bytes>maximum)throw Error('too-large');html+=decoder.decode(chunk.value,{stream:true});}
        html+=decoder.decode();
      }finally{await reader.cancel();}
      if(!current())return;
      const template=document.createElement('template');template.innerHTML=html;
      const title=template.content.querySelector('title')?.textContent||'';
      template.content.querySelectorAll('script,style,noscript,template,svg,canvas,iframe,object,embed').forEach(node=>node.remove());
      const page=template.content.querySelector('main,[role="main"],article')||template.content;
      const text=page.textContent.trim();if(!text)throw Error('unavailable');
      const preview=document.createElement('div');preview.className='plainpreview';
      preview.textContent=(title?title+'\n\n':'')+text.slice(0,100000);
      if(!current())return;
      frame.hidden=true;canvas.append(preview);
      $('#previewfoot').textContent=text.length>100000?'Read-only text preview · shortened. Use Open for the full page.':'Read-only text preview · use Open for the full page.';
    }catch(error){
      if(current())$('#previewfoot').textContent=request.timedOut?'Text preview timed out. Use Open.':error.message==='too-large'?'Page too large for a text preview. Use Open.':'Preview blocked or unavailable. Use Open.';
    }finally{clearTimeout(request.timer);request.controller.abort();if(readableRequest===request)readableRequest=null;}
  }
  function closePreview(focus=false){
    if(previewActive)mainHeight=previewReturnHeight;
    previewActive=false;previewEntry=null;releaseMedia();layout();updateSelected();
    if(focus&&returnFocus&&returnFocus.isConnected)returnFocus.focus({preventScroll:true});
  }
  function showPreview(entry,trigger){
    if(!previewActive){previewReturnHeight=mainHeight;mainHeight=Math.max(mainHeight,vh()*.90);}
    previewEntry=entry;previewActive=true;returnFocus=trigger||returnFocus;releaseMedia();
    const token=previewToken, url=entry.value, web=/^https?:\/\//i.test(url), blob=/^blob:/i.test(url);
    const image=entry.type==='Images'||/\.(?:png|jpe?g|gif|webp|avif|bmp|svg)(?:[?#]|$)/i.test(url);
    const video=entry.type==='Video'||/\.(?:mp4|m4v|webm|mov|ogv)(?:[?#]|$)/i.test(url);
    const audio=entry.type==='Audio'||/\.(?:mp3|m4a|ogg|wav|aac|flac)(?:[?#]|$)/i.test(url);
    $('#previewaddress').textContent=url;$('#previewaddress').title=url;
    $('#previewkind').textContent=entry.type+' · '+entry.label;
    $('#previewopen').disabled=!web;
    const status=text=>{if(!closed&&token===previewToken)$('#previewfoot').textContent=text;};
    const discovery=[
      'a[href]','area[href]','form[action]','img[src]','img[data-src]','img[data-original]',
      'img.currentSrc','srcset','video[src]','video[data-src]','video[poster]','video.currentSrc',
      'audio[src]','audio[data-src]','audio.currentSrc','source[src]','script[src]','link[rel]',
      'link[imagesrcset]','iframe[src]','frame[src]','embed[src]','object[data]','style=url()',
      'meta','document.title','location','Performance API'
    ].some(source=>(typeof entry.source==='string'?entry.source:'').split(' · ').includes(source))?'Discovered via '+entry.source:'';
    if((web||blob)&&entry.url){
      if(image){
        const stage=document.createElement('div');stage.className='imagestage';const img=document.createElement('img');img.alt=entry.label||'Image preview';img.src=url;img.referrerPolicy='no-referrer';
        img.onerror=()=>status('Image unavailable here. Try Open.');stage.append(img);canvas.append(stage);status(discovery||'Image preview · drag the handle for more room.');
      }else if(video||audio){
        const media=document.createElement(video?'video':'audio');media.controls=true;media.preload='metadata';media.src=url;
        media.onerror=()=>status('This source cannot play here. Try Open.');
        if(video){media.playsInline=true;canvas.append(media);}else{const stage=document.createElement('div');stage.className='audiostage';stage.innerHTML='<span class="avatar">'+icon('audio')+'</span>';stage.append(media);canvas.append(stage);}
        status(entry.manifest?'Manifest preview · requires a compatible player; playback unverified.':discovery?discovery+' · May not play.':(video?'Video':'Audio')+' preview · playback depends on the source.');
      }else if(web||blob){
        const frame=document.createElement('iframe');frame.title='Peek: '+entry.label;
        frame.setAttribute('sandbox','allow-scripts allow-forms allow-same-origin');frame.referrerPolicy='no-referrer';frame.src=url;
        peekFrame=frame;
        frame.dataset.loading='true';
        frame.addEventListener('load',()=>{
          frame.dataset.loading='false';
          if(peekFrame===frame){updatePreviewAddress(previewUrl());readablePreview(frame,url,token);}
        });
        canvas.append(frame);
        $('#inspectpage').hidden=!preferences.visibility.inspectpage;
        status(discovery?discovery+' · If blocked, use Open.':'Some sites block embedded previews. Use Open if this stays blank.');
        frame.dataset.previewStatus=$('#previewfoot').textContent;
        frame.addEventListener('error',()=>readablePreview(frame,url,token,true));
      }else{const p=document.createElement('div');p.className='plainpreview';p.textContent=url;canvas.append(p);status('This resource is available to copy.');}
    }else{
      const p=document.createElement('div');p.className='plainpreview';p.textContent=url;canvas.append(p);status(entry.url?'Link scheme shown as text. Copy it to use elsewhere.':(discovery||'Metadata · a small detail, a little more context.'));
    }
    layout();updateSelected();
  }
  function openExternal(){
    const url=previewUrl();
    if(!/^https?:\/\//i.test(url))return;
    const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener noreferrer';root.append(a);a.click();a.remove();
  }
  function toggleMini(){
    mini=!mini;sheet.classList.toggle('minimized',mini);
    if(mini)closePreview();
    $('#minimize').innerHTML=icon(mini?'eye':'minimize');$('#minimize').setAttribute('aria-label',mini?'Restore Nous':'Minimize Nous');layout();
  }
  function toggleFull(){
    if(mini)toggleMini();
    full=!full;if(full){rememberedHeight=mainHeight;mainHeight=vh()-12;}else mainHeight=rememberedHeight;layout();
  }
  function resizeHandle(handle,kind,titlebar){
    let active=false,startY=0,startHeight=0,pointerId=null,touchId=null,dragController=null;
    const blocked=event=>event.target&&event.target.closest&&event.target.closest('button,input,select,a,textarea');
    function moveTo(y,event){
      if(!active||!Number.isFinite(y))return;
      if(event.cancelable)event.preventDefault();
      const next=startHeight+startY-y;
      if(kind==='preview')previewHeight=next;else{mainHeight=next;full=false;}
      layout();
    }
    function finish(cancelled=false){
      if(!active)return;
      active=false;
      if(dragController){dragController.abort();dragController=null;}
      try{if(pointerId!==null)handle.releasePointerCapture(pointerId);}catch{}
      pointerId=null;touchId=null;
      handle.classList.remove('held');$('.dock').classList.remove('dragging');$('#dragshield').hidden=true;
      if(!cancelled)rememberPanelSize(kind);
    }
    function begin(y,event,id,touch){
      if(active||mini||blocked(event)||!Number.isFinite(y))return false;
      active=true;startY=y;startHeight=kind==='preview'?previewHeight:mainHeight;
      pointerId=id;touchId=touch;dragController=new AbortController();
      if(event.cancelable)event.preventDefault();
      event.stopPropagation();
      handle.classList.add('held');$('.dock').classList.add('dragging');
      if(id!==null)try{handle.setPointerCapture(id);}catch{}
      $('#dragshield').hidden=false;
      return true;
    }
    function watch(name,fn){window.addEventListener(name,fn,{capture:true,passive:false,signal:dragController.signal});}
    function pointerStart(event){
      if(event.isPrimary===false||(event.pointerType==='mouse'&&event.button!==0))return;
      if(!begin(event.clientY,event,event.pointerId,null))return;
      watch('pointermove',e=>{if(e.pointerId===pointerId)moveTo(e.clientY,e);});
      watch('pointerup',e=>{if(e.pointerId===pointerId){moveTo(e.clientY,e);finish();}});
      watch('pointercancel',e=>{if(e.pointerId===pointerId)finish(true);});
      watch('blur',()=>finish(true));
    }
    function touchStart(event){
      if(!event.changedTouches||!event.changedTouches.length||event.touches.length!==1)return;
      const t=event.changedTouches[0];
      if(!begin(t.clientY,event,null,t.identifier))return;
      const findTouch=list=>Array.from(list||[]).find(touch=>touch.identifier===touchId);
      watch('touchmove',e=>{const t=findTouch(e.touches);if(t)moveTo(t.clientY,e);});
      watch('touchend',e=>{const t=findTouch(e.changedTouches);if(t){moveTo(t.clientY,e);finish();}});
      watch('touchcancel',()=>finish(true));watch('blur',()=>finish(true));
    }
    function mouseStart(event){
      if(event.button!==0||!begin(event.clientY,event,null,null))return;
      watch('mousemove',e=>moveTo(e.clientY,e));watch('mouseup',e=>{moveTo(e.clientY,e);finish();});watch('blur',()=>finish(true));
    }
    for(const target of [handle,titlebar]){
      if(window.PointerEvent)on(target,'pointerdown',pointerStart,{passive:false});
      else{on(target,'touchstart',touchStart,{passive:false});on(target,'mousedown',mouseStart);}
      on(target,'selectstart',event=>event.preventDefault());
    }
    on(handle,'keydown',event=>{
      if(mini)return;
      if(event.key==='ArrowUp'||event.key==='ArrowDown'){
        event.preventDefault();const delta=event.key==='ArrowUp'?28:-28;
        if(kind==='preview')previewHeight+=delta;else{mainHeight+=delta;full=false;}
        layout();rememberPanelSize(kind);
      }
    });
    controller.signal.addEventListener('abort',()=>finish(true),{once:true});
  }
  resizeHandle($('#grab'),'main',$('.bar'));resizeHandle($('#previewgrab'),'preview',$('.peekbar'));

  on($('#settingstab'),'click',()=>setSettingsView(!settingsOpen));
  on($('#sourcestab'),'click',()=>setSourcesView(!sourcesOpen));
  on($('#sourcecopy'),'click',()=>copyText(sourceSnapshot));
  on(window,'securitypolicyviolation',event=>{
    if(!peekFrame||!previewEntry||!['frame-src','child-src'].includes(event.effectiveDirective))return;
    try{if(new URL(event.blockedURI).href.split('#')[0]===new URL(previewEntry.value).href.split('#')[0])readablePreview(peekFrame,previewEntry.value,previewToken,true);}catch{}
  });
  for(const key of ['theme','accent','density'])on($('#setting-'+key),'change',event=>{changePreference(key,event.target.value);savePreferences();});
  for(const key of ['textSize','inspectorHeight','previewHeight']){
    on($('#setting-'+key),'input',event=>changePreference(key,Number(event.target.value)));
    on($('#setting-'+key),'change',savePreferences);
  }
  for(const key of ['wrapUrls','rememberSizes'])on($('#setting-'+key),'change',event=>{changePreference(key,event.target.checked);savePreferences();});
  for(const key of Object.keys(DEFAULTS.visibility))on($('#setting-visible-'+key),'change',event=>changeVisibility(key,event.target.checked));
  on($('#settingsreset'),'click',()=>{
    preferences={...DEFAULTS};mainHeight=vh()*.60;previewHeight=vh()*.34;
    rememberedHeight=mainHeight;previewReturnHeight=mainHeight;full=false;
    applyPreferences();syncSettings();savePreferences();layout();note('Settings reset.');
  });
  if(colorQuery&&colorQuery.addEventListener)on(colorQuery,'change',applyPreferences);

  on($('#find'),'input',()=>{limit=80;render();$('#items').scrollTop=0;});
  on($('#scan'),'click',rescanCurrent);
  on($('#inspectpage'),'click',inspectPreview);
  on($('#inspectback'),'click',backInspection);
  on($('#copy'),'click',()=>copyText(filtered.map(entry=>entry.type+'\t'+entry.label+'\t'+entry.value).join('\n')));
  on($('#save'),'click',()=>{
    const data={app:'Nous',version:'1.6',page:currentScan.url,capturedAt:new Date().toISOString(),entries:filtered};
    const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));downloads.add(url);
    const a=document.createElement('a');a.href=url;a.download='nous-resources.json';root.append(a);a.click();a.remove();
    later(()=>{URL.revokeObjectURL(url);downloads.delete(url);},30000);note('Your threads, exported.');
  });
  on($('#previewclose'),'click',()=>closePreview(true));on($('#previewcopy'),'click',()=>{if(previewEntry)copyText(previewUrl());});on($('#previewopen'),'click',openExternal);
  on($('#close'),'click',closeNous);on($('#minimize'),'click',toggleMini);on($('#maximize'),'click',toggleFull);
  const closeCopy=()=>{$('#copydialog').hidden=true;$('#find').focus({preventScroll:true});};
  on($('#copydialogclose'),'click',closeCopy);on($('#selecttext'),'click',()=>{$('#copytext').focus();$('#copytext').select();$('#copytext').setSelectionRange(0,$('#copytext').value.length);});
  on(root,'keydown',event=>{if(event.key==='Escape'){event.preventDefault();if(!$('#copydialog').hidden)closeCopy();else if(settingsOpen)setSettingsView(false);else if(sourcesOpen)setSourcesView(false);else if(previewActive)closePreview(true);else closeNous();}});
  on(window,'resize',layout,{passive:true});
  if(viewport){on(viewport,'resize',layout,{passive:true});on(viewport,'scroll',layout,{passive:true});}
  applyPreferences();syncSettings();collect();render();layout();
})();

/* NOUS_SOURCE_END */
    const opened=!!document.getElementById(id);
    if(opened===!!previous)throw new Error('The inspector did not change state. Reload this page before trying again.');
    return {ok:true,opened};
  }catch(error){
    const created=document.getElementById(id);
    if(!previous&&created)created.remove();
    return {ok:false,error:error instanceof Error?error.message:String(error)};
  }
})();
